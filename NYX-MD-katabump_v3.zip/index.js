import fs from 'node:fs';
import path from 'node:path';
import readline from 'node:readline';
import makeWASocket, { useMultiFileAuthState, DisconnectReason, Browsers, fetchLatestBaileysVersion, makeCacheableSignalKeyStore } from '@whiskeysockets/baileys';
import { config } from './config.js';
import { db, flushAll, logError } from './lib/database.js';
import { log, baileysLogger } from './lib/logger.js';
import { cleanTemp, sleep } from './lib/utils.js';
import { loadCommands } from './handler/commandHandler.js';
import { onMessages, trackSent } from './handler/messageHandler.js';
import { onParticipants } from './handler/groupEvents.js';
import { invalidateMeta } from './lib/groupUtils.js';
import * as statusManager from './lib/statusManager.js';
import { runtime } from './lib/runtime.js';
import { sendBanner, frame } from './lib/ui.js';

/* ── Verrou : une seule instance par session ── */
const lockFile = path.join(config.paths.session, '.lock');
fs.mkdirSync(config.paths.session, { recursive: true });
try {
  const old = Number(fs.readFileSync(lockFile, 'utf8'));
  if (old && old !== process.pid) { try { process.kill(old, 0); console.error(`Une autre instance de NYX MD (PID ${old}) utilise deja cette session. Arret.`); process.exit(1); } catch (e) { if (e.code === 'EPERM') process.exit(1); } }
} catch {}
fs.writeFileSync(lockFile, String(process.pid));
const releaseLock = () => { try { if (Number(fs.readFileSync(lockFile, 'utf8')) === process.pid) fs.unlinkSync(lockFile); } catch {} };

let sock = null, starting = false, retry = 0, stopping = false, timersStarted = false, announced = false;
const msgCache = new Map();

const ask = (q) => new Promise((res) => { const rl = readline.createInterface({ input: process.stdin, output: process.stdout }); rl.question(q, (a) => { rl.close(); res(a); }); });

async function teardown() {
  if (!sock) return;
  const s = sock; sock = null;
  try { s.ev.removeAllListeners(); } catch {}
  try { s.ws?.removeAllListeners?.(); } catch {}
  try { s.end(undefined); } catch {}
}

async function start() {
  if (starting || stopping) return;
  starting = true;
  try {
    await teardown();
    const { state, saveCreds } = await useMultiFileAuthState(config.paths.session);
    const { version } = await fetchLatestBaileysVersion().catch(() => ({}));
    const s = makeWASocket({
      ...(version ? { version } : {}),
      logger: baileysLogger,
      auth: { creds: state.creds, keys: makeCacheableSignalKeyStore(state.keys, baileysLogger) },
      browser: Browsers.ubuntu('Chrome'),
      printQRInTerminal: false, markOnlineOnConnect: false, syncFullHistory: false, generateHighQualityLinkPreview: false,
      getMessage: async (key) => msgCache.get(key.id)
    });
    sock = s; runtime.sock = s; trackSent(s);
    let pairingAsked = false;

    s.ev.on('creds.update', saveCreds);

    s.ev.on('connection.update', async (u) => {
      const { connection, lastDisconnect, qr } = u;
      if (qr && !s.authState.creds.registered && !pairingAsked) {
        pairingAsked = true;
        let number = config.pairingNumber;
        if (!number && process.stdin.isTTY) number = (await ask('Numero WhatsApp du bot (format international, sans +) : ')).replace(/\D/g, '');
        if (!number) { log.error('PAIRING_NUMBER (ou OWNER_NUMBER) manquant dans config.js : impossible de generer le Pairing Code.'); return; }
        try {
          const code = await s.requestPairingCode(number);
          const pretty = code?.match(/.{1,4}/g)?.join('-') || code;
          console.log('\n\x1b[35m╭━━━━━━━━━━━━━━━━━━━━━━━━━━━╮\n┃  🌑 NYX MD — PAIRING CODE  ┃\n┃                           ┃\n┃       \x1b[1m' + pretty + '\x1b[0m\x1b[35m          ┃\n╰━━━━━━━━━━━━━━━━━━━━━━━━━━━╯\x1b[0m');
          console.log('WhatsApp > Appareils connectes > Connecter un appareil > Lier avec un numero de telephone, puis saisissez le code.\n');
        } catch (e) { log.error('Pairing Code :', e.message); logError('pairing', e); }
      }
      if (connection === 'open') {
        retry = 0; runtime.connectedAt = Date.now();
        log.info(`Connecte en tant que ${s.user?.id}`);
        if (!timersStarted) { timersStarted = true; setInterval(cleanTemp, 10 * 60 * 1000).unref(); setInterval(statusManager.cleanup, 60 * 60 * 1000).unref(); }
        if (!announced && config.ownerNumber) {
          announced = true;
          sendBanner(s, `${config.ownerNumber}@s.whatsapp.net`, frame('ONLINE', ['✅ Bot connecte', `🔧 Prefixe : ${db.settings.data.prefix}`, `🌐 Mode : ${db.settings.data.mode}`, `📜 Tapez ${db.settings.data.prefix}menu`])).catch(() => {});
        }
      }
      if (connection === 'close') {
        if (s !== sock) return;
        const code = lastDisconnect?.error?.output?.statusCode;
        log.warn(`Connexion fermee (code ${code ?? '?'}).`);
        if (stopping) return;
        if (code === DisconnectReason.loggedOut) { log.error('Session deconnectee depuis le telephone. Supprimez le dossier session/ puis relancez pour generer un nouveau Pairing Code.'); return; }
        if (code === DisconnectReason.connectionReplaced) { log.error('Session ouverte ailleurs (conflit). Fermez l\'autre instance. Pas de reconnexion automatique.'); return; }
        const delay = code === DisconnectReason.restartRequired ? 500 : Math.min(30000, 1000 * 2 ** retry++);
        await teardown(); starting = false;
        setTimeout(() => start().catch((e) => log.error('restart:', e.message)), delay);
      }
    });

    s.ev.on('messages.upsert', (ev) => {
      for (const m of ev.messages) if (m.key?.id && m.message) { msgCache.set(m.key.id, m.message); if (msgCache.size > 800) msgCache.delete(msgCache.keys().next().value); }
      onMessages(s, ev, baileysLogger);
    });
    s.ev.on('group-participants.update', (ev) => onParticipants(s, ev).catch((e) => logError('groupEvents', e)));
    s.ev.on('groups.update', (arr) => arr.forEach((g) => g.id && invalidateMeta(g.id)));
  } catch (e) {
    log.error('Demarrage :', e.message); logError('start', e);
    starting = false; if (!stopping) setTimeout(() => start(), Math.min(30000, 2000 * 2 ** retry++));
    return;
  }
  starting = false;
}

runtime.restart = async () => { retry = 0; announced = true; await teardown(); await sleep(800); starting = false; await start(); };
runtime.shutdown = async () => { stopping = true; flushAll(); await teardown(); releaseLock(); process.exit(0); };
runtime.hardRestart = () => { flushAll(); releaseLock(); process.exit(1); };

process.on('unhandledRejection', (e) => { logError('unhandledRejection', e); log.error('unhandledRejection:', e?.message || e); });
process.on('uncaughtException', (e) => { logError('uncaughtException', e); log.error('uncaughtException:', e?.message || e); });
for (const sig of ['SIGINT', 'SIGTERM']) process.on(sig, () => { stopping = true; flushAll(); releaseLock(); process.exit(0); });
process.on('exit', releaseLock);

console.log('\x1b[35m\n  ╭──────────────────────────────╮\n  │   🌑  N Y X   M D   v1.0     │\n  │   dark • futuristic • smart  │\n  ╰──────────────────────────────╯\x1b[0m');
if (!config.ownerNumber) log.warn('OWNER_NUMBER non defini dans config.js : aucune commande owner ne sera accessible (hors compte du bot).');
await loadCommands();
await start();
