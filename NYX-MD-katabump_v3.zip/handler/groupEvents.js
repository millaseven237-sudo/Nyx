import { db } from '../lib/database.js';
import { getGroupMeta, invalidateMeta, groupSettings } from '../lib/groupUtils.js';
import { numberOf } from '../lib/jidManager.js';
import { menuImage, frame } from '../lib/ui.js';
import { log } from '../lib/logger.js';

const fill = (tpl, { user, group, count, desc }) => tpl.replace(/@user/g, `@${user}`).replace(/@group/g, group).replace(/@count/g, String(count)).replace(/@desc/g, desc || '');

export async function onParticipants(sock, ev) {
  invalidateMeta(ev.id);
  const g = groupSettings(ev.id);
  if (!['add', 'remove'].includes(ev.action)) return;
  if ((ev.action === 'add' && !g.welcome) || (ev.action === 'remove' && !g.goodbye)) return;
  let meta; try { meta = await getGroupMeta(sock, ev.id, true); } catch { return; }
  for (const p of ev.participants) {
    const jid = typeof p === 'string' ? p : p.phoneNumber || p.id;
    try {
      const vars = { user: numberOf(jid), group: meta.subject, count: meta.participants.length, desc: meta.desc };
      const welcome = ev.action === 'add';
      const text = fill(welcome ? (g.welcomeText || '🌑 Bienvenue @user dans *@group* !\n👥 Membres : @count\n💜 Lis la description et respecte les regles.') : (g.goodbyeText || '🌒 @user a quitte *@group*.\n💜 Bonne route…'), vars);
      const caption = frame(welcome ? 'WELCOME' : 'GOODBYE', text.split('\n'));
      let img; try { img = (await sock.profilePictureUrl(jid, 'image')) ? { url: await sock.profilePictureUrl(jid, 'image') } : null; } catch { img = null; }
      const image = img || menuImage();
      if (image) await sock.sendMessage(ev.id, { image, caption, mentions: [jid] });
      else await sock.sendMessage(ev.id, { text: caption, mentions: [jid] });
    } catch (e) { log.warn('group event:', e.message); }
  }
}
