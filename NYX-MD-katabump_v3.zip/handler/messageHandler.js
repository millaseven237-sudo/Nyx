import { isJidBot, getContentType } from '@whiskeysockets/baileys';
import { config } from '../config.js';
import { db, S, logError } from '../lib/database.js';
import { log } from '../lib/logger.js';
import { findCommand, countUse } from './commandHandler.js';
import { checkPermission, isOwnerIds } from './permissionHandler.js';
import { resolveSender, sameUser, extractTargets } from './jidHandler.js';
import { getText, getQuoted, getContextInfo, unwrap, mediaInfo, findMedia, downloadBuffer } from '../lib/utils.js';
import { isGroup as isGroupJid, isNewsletter, numberOf } from '../lib/jidManager.js';
import { adminState, groupSettings } from '../lib/groupUtils.js';
import { onStatus } from '../lib/statusManager.js';
import * as nyx from '../lib/nyxEngine.js';
import * as sticker from '../lib/stickerEngine.js';
import { fail, warn, replyContext } from '../lib/ui.js';

export const sentIds = new Set();   // ids des messages envoyes par le bot (evite les boucles)
const lastCmd = new Map();
const spam = new Map();
const IGNORED = ['protocolMessage', 'senderKeyDistributionMessage', 'reactionMessage', 'pollUpdateMessage', 'keepInChatMessage', 'encReactionMessage'];

export function trackSent(sock) {
  const orig = sock.sendMessage.bind(sock);
  sock.sendMessage = async (jid, content, ...rest) => {
    // Chaine + carte cliquable sous chaque reponse textuelle / image / video / document du bot
    try {
      const ctx = replyContext();
      const plain = content && !content.edit && !content.react && !content.delete && !content.poll && !content.forward && (content.text || content.image || content.video || content.document);
      if (ctx && plain && !jid.endsWith('@newsletter') && jid !== 'status@broadcast' && !content.statusJidList) content = { ...content, contextInfo: { ...ctx, ...(content.contextInfo || {}) } };
    } catch {}
    const r = await orig(jid, content, ...rest);
    if (r?.key?.id) { sentIds.add(r.key.id); if (sentIds.size > 2000) sentIds.delete(sentIds.values().next().value); }
    return r;
  };
}

export function onMessages(sock, ev, logger) {
  if (ev.type !== 'notify') return;
  for (const m of ev.messages) handle(sock, m, logger).catch((e) => { logError('message', e); log.error('message:', e.message); });
}

async function handle(sock, m, logger) {
  const chat = m.key.remoteJid;
  if (!chat || !m.message) return;
  if (chat === 'status@broadcast') return onStatus(sock, m, logger);
  if (isNewsletter(chat) || chat.endsWith('@broadcast')) return;
  if (m.key.id && sentIds.has(m.key.id)) return;

  const content = unwrap(m.message); if (!content) return;
  const mtype = getContentType(content);
  if (IGNORED.includes(mtype)) return;

  const text = getText(m.message);
  const prefix = S().prefix || config.prefix;
  const isCmd = text.startsWith(prefix) && text.length > prefix.length;
  if (m.key.fromMe && !isCmd) return;                         // le compte du bot ne s'auto-declenche que par commande

  const isGroup = isGroupJid(chat);
  const snd = resolveSender(m, sock);
  const isOwner = isOwnerIds(snd.all, m.key.fromMe);
  db.stats.data.messages++;

  // registre des utilisateurs
  const uKey = snd.jid; const u = (db.users.data.list[uKey] ||= { first: Date.now(), count: 0 });
  u.last = Date.now(); u.count++; if (m.pushName) u.name = m.pushName; if (!isGroup) u.dm = true; db.users.save();

  const quoted = getQuoted(m);
  let st = { meta: null, isAdmin: false, isBotAdmin: false };
  if (isGroup) st = await adminState(sock, chat, snd.all);

  const c = {
    sock, m, chat, isGroup, logger, prefix, isOwner, sender: snd.jid, senderIds: snd.all, pushName: m.pushName || '',
    quoted, meta: st.meta, isAdmin: st.isAdmin || isOwner, isBotAdmin: st.isBotAdmin, text: '', args: [], command: '',
    reply: (t, o = {}) => sock.sendMessage(chat, { text: t, ...o }, { quoted: m }),
    send: (cnt, o = {}) => sock.sendMessage(chat, cnt, { quoted: m, ...o }),
    react: (e) => sock.sendMessage(chat, { react: { text: e, key: m.key } }).catch(() => {})
  };

  // ── Protections de groupe (avant les commandes)
  if (isGroup && !m.key.fromMe && !c.isAdmin && !isCmd) { if (await groupGuards(c, text)) return; }
  if (isGroup && !m.key.fromMe && !isOwner && (db.muted.data.list[chat] || []).some((j) => sameUser(snd.all, j)) && st.isBotAdmin) {
    return void sock.sendMessage(chat, { delete: m.key }).catch(() => {});
  }

  // ── AFK
  await afkHandler(c, text, isCmd);

  // ── Session de creation de pack de stickers
  if (!isCmd && !m.key.fromMe && (await packSession(c))) return;

  // ── Commandes
  if (isCmd) {
    const mm = text.slice(prefix.length).trim().match(/^(\S+)\s*([\s\S]*)$/);
    if (!mm) return;
    const cmd = findCommand(mm[1]);
    if (!cmd) return;
    c.command = mm[1].toLowerCase(); c.text = mm[2].trim(); c.args = c.text ? c.text.split(/\s+/) : [];
    const perm = checkPermission(cmd, c);
    if (!perm.ok) { if (!perm.silent) await c.reply(fail(perm.reason)); return; }
    if (!isOwner) { const k = snd.jid, t = lastCmd.get(k) || 0; if (Date.now() - t < S().commandCooldownMs) return; lastCmd.set(k, Date.now()); if (lastCmd.size > 2000) lastCmd.delete(lastCmd.keys().next().value); }
    countUse(cmd);
    try { await cmd.run(c); }
    catch (e) { logError(`cmd:${cmd.name}`, e); log.error(`Commande ${cmd.name}:`, e.message); await c.reply(fail(`Erreur : ${String(e.message).slice(0, 300)}`)).catch(() => {}); }
    return;
  }

  // ── NYX : declenchement cache par mot-cle / reponse
  const ctx = getContextInfo(m.message);
  const repliedToBot = !!ctx?.participant && sameUser(ctx.participant, [sock.user?.id, sock.user?.lid].filter(Boolean));
  if (!m.key.fromMe && nyx.shouldTrigger({ text, isGroup, repliedToBot, isOwner })) {
    if (nyx.onCooldown(`${chat}:${snd.jid}`)) return;
    // "nyx" seul en reponse a un message -> NYX analyse le message cite
    const words = nyx.nyxWords();
    const rest = text.toLowerCase().replace(/[^\p{L}\p{N}\s]/gu, '').split(/\s+/).filter((w) => w && !words.includes(w));
    const target = quoted && !repliedToBot && rest.length === 0 ? { key: quoted.key, message: quoted.message } : { key: m.key, message: m.message };
    const r = await nyx.reply({ sock, target, logger, silent: S().nyx.mode === 'discret' });
    if (r?.text) await c.reply(r.text);
  }
}

/* ── Garde-fous de groupe : antilink / antispam / antibot ── */
async function groupGuards(c, text) {
  const { sock, m, chat, sender } = c; const g = groupSettings(chat);
  const del = () => sock.sendMessage(chat, { delete: m.key }).catch(() => {});
  const kick = () => sock.groupParticipantsUpdate(chat, [sender], 'remove').catch(() => {});

  if (g.antibot && c.isBotAdmin && /^BAE5/.test(m.key.id || '') && !m.key.fromMe) {
    await del(); await c.reply(warn('Bot detecte (heuristique sur l\'identifiant du message). Retire du groupe.')); await kick(); return true;
  }
  if (g.antibot && c.isBotAdmin && isJidBot(sender)) { await del(); await kick(); return true; }

  if (g.antilink && c.isBotAdmin) {
    const re = g.antilinkAll ? /(https?:\/\/|www\.)\S+/i : /chat\.whatsapp\.com\/[A-Za-z0-9]{16,}/i;
    if (re.test(text)) {
      await del();
      if (g.antilinkAction === 'kick') { await c.reply(warn(`@${numberOf(sender)} liens interdits : exclusion.`), { mentions: [sender] }); await kick(); }
      else await c.reply(warn(`@${numberOf(sender)} les liens ne sont pas autorises ici.`), { mentions: [sender] });
      return true;
    }
  }

  if (g.antispam && c.isBotAdmin) {
    const { maxMessages, perSeconds } = S().antispam; const k = `${chat}:${sender}`; const now = Date.now();
    const arr = (spam.get(k) || []).filter((t) => now - t < perSeconds * 1000); arr.push(now); spam.set(k, arr);
    if (spam.size > 3000) spam.delete(spam.keys().next().value);
    if (arr.length > maxMessages) {
      await del();
      if (arr.length === maxMessages + 1) await c.reply(warn(`@${numberOf(sender)} ralentissez (anti-spam).`), { mentions: [sender] });
      if (arr.length >= maxMessages + 4) { await kick(); spam.delete(k); }
      return true;
    }
  }
  return false;
}

/* ── AFK ── */
async function afkHandler(c, text, isCmd) {
  const { m, sender } = c; const list = db.afk.data.list;
  const me = list[numberOf(sender)];
  if (me && !/^\S?afk\b/i.test(text.slice(c.prefix.length)) && !m.key.fromMe) {
    delete list[numberOf(sender)]; db.afk.save();
    await c.reply(`💜 Bon retour ! Tu etais AFK depuis ${Math.max(1, Math.round((Date.now() - me.since) / 60000))} min.`);
  }
  if (isCmd) return;
  const targets = [...(getContextInfo(m.message)?.mentionedJid || []), c.quoted?.sender].filter(Boolean);
  for (const t of targets) {
    const a = list[numberOf(t)] || list[db.lidmap.data.map[numberOf(t)]];
    if (a) await c.reply(`💤 @${numberOf(t)} est AFK${a.reason ? ` : ${a.reason}` : ''} (depuis ${Math.max(1, Math.round((Date.now() - a.since) / 60000))} min).`, { mentions: [t] });
  }
}

/* ── Creation de pack : chaque sticker (ou image/video) envoye est ajoute ── */
async function packSession(c) {
  const pack = sticker.activePack(c.sender); if (!pack || pack.chat !== c.chat) return false;
  const info = mediaInfo(c.m.message); if (!info) return false;
  const isSticker = info.kind === 'sticker';
  if (!isSticker && !(pack.auto && ['image', 'video'].includes(info.kind))) return false;
  try {
    let buf = await downloadBuffer(c.sock, { key: c.m.key, message: c.m.message }, c.logger);
    if (!isSticker) buf = await sticker.mediaToWebp(buf, { mime: info.mime, isVideo: info.kind === 'video', crop: false });
    const n = await sticker.addToPack(pack, buf, pack.emojis || ['✨']);
    const done = n >= Math.min(60, S().stickerPackLimit);
    await c.reply(sticker.progressText(pack) + (done ? `\n🎉 Pack complet ! Export en cours…` : '\nEnvoyez le prochain sticker.'));
    if (done) { await finishAndSend(c, pack); }
  } catch (e) { await c.reply(fail(e.message)); }
  return true;
}

export async function finishAndSend(c, pack) {
  sticker.finishPack(pack);
  const zip = await sticker.exportZip(pack);
  const fs = await import('node:fs');
  try {
    await c.sock.sendMessage(c.chat, { document: fs.readFileSync(zip), mimetype: 'application/zip', fileName: `${pack.name.replace(/[^\w-]+/g, '_')}_${pack.files.length}stickers.zip`, caption: `📦 Pack *${pack.name}* — ${pack.files.length} stickers` }, { quoted: c.m });
  } finally { fs.unlinkSync(zip); }
}
