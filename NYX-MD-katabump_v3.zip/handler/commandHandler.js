import fs from 'node:fs';
import path from 'node:path';
import { pathToFileURL } from 'node:url';
import { config } from '../config.js';
import { log } from '../lib/logger.js';
import { db, logError } from '../lib/database.js';

export const registry = new Map();   // nom/alias -> commande
export const commands = [];          // liste unique
export const loadErrors = [];

const dir = path.join(config.root, 'commands');

export async function loadCommands(bust = false) {
  registry.clear(); commands.length = 0; loadErrors.length = 0;
  for (const cat of fs.readdirSync(dir, { withFileTypes: true }).filter((d) => d.isDirectory())) {
    for (const f of fs.readdirSync(path.join(dir, cat.name)).filter((x) => x.endsWith('.js'))) {
      const file = path.join(dir, cat.name, f);
      try {
        const mod = await import(pathToFileURL(file).href + (bust ? `?v=${Date.now()}` : ''));
        const list = [].concat(mod.default || []);
        for (const cmd of list) {
          if (!cmd?.name || typeof cmd.run !== 'function') throw new Error(`commande invalide dans ${f}`);
          cmd.category = cmd.category || cat.name;
          cmd.file = `${cat.name}/${f}`;
          if (cmd.category === 'hidden') cmd.hidden = true;
          for (const n of [cmd.name, ...(cmd.aliases || [])]) {
            if (registry.has(n)) log.warn(`Conflit de commande "${n}" (${registry.get(n).file} / ${cmd.file})`);
            registry.set(n, cmd);
          }
          commands.push(cmd);
        }
      } catch (e) { loadErrors.push(`${cat.name}/${f}: ${e.message}`); logError('load:' + f, e); log.error(`Plugin ${cat.name}/${f} :`, e.message); }
    }
  }
  log.info(`${commands.length} commandes chargees (${registry.size} noms/alias), ${loadErrors.length} erreur(s).`);
}

export const findCommand = (name) => registry.get(String(name || '').toLowerCase());

export function countUse(cmd) {
  const s = db.stats.data.commands; s[cmd.name] = (s[cmd.name] || 0) + 1; db.stats.save();
}
