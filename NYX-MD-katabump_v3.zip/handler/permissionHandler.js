import { db, S } from '../lib/database.js';
import { config } from '../config.js';
import { numberOf } from '../lib/jidManager.js';
import { sameUser } from './jidHandler.js';

export function isOwnerIds(ids, fromMe = false) {
  if (fromMe) return true;
  const owners = [config.ownerNumber, ...db.owners.data.secondary].filter(Boolean);
  return ids.some((j) => { const n = numberOf(j); return owners.includes(n) || owners.includes(db.lidmap.data.map[n]); });
}
export const isPrimaryOwner = (ids) => ids.some((j) => { const n = numberOf(j); return n === config.ownerNumber || db.lidmap.data.map[n] === config.ownerNumber; });

export const LEVELS = ['public', 'admin', 'owner'];

// Retourne { ok, reason }
export function checkPermission(cmd, c) {
  const ov = db.perms.data.commands[cmd.name] || {};
  if (ov.disabled || db.perms.data.features[cmd.category] === false) {
    if (!c.isOwner) return { ok: false, reason: 'Cette commande est desactivee par le proprietaire.' };
  }
  if (c.isOwner) return { ok: true };
  if (S().mode === 'private' && !cmd.hidden) return { ok: false, silent: true, reason: 'Le bot est en mode prive.' };
  if ((ov.deny || []).some((j) => sameUser(c.senderIds, j))) return { ok: false, reason: 'Acces refuse pour cette commande.' };
  const level = ov.level || cmd.access || 'public';
  const allowed = (ov.allow || []).some((j) => sameUser(c.senderIds, j));
  if (level === 'owner' && !allowed) return { ok: false, reason: 'Commande reservee au proprietaire.' };
  if (cmd.group && !c.isGroup) return { ok: false, reason: 'Cette commande fonctionne uniquement dans un groupe.' };
  if (cmd.private && c.isGroup) return { ok: false, reason: 'Cette commande fonctionne uniquement en prive.' };
  if (level === 'admin' && !allowed) {
    if (!c.isGroup) return { ok: false, reason: 'Commande reservee aux admins de groupe.' };
    if (!c.isAdmin) return { ok: false, reason: 'Commande reservee aux admins du groupe.' };
  }
  if (cmd.botAdmin && !c.isBotAdmin) return { ok: false, reason: 'Je dois etre admin du groupe pour executer cette commande.' };
  return { ok: true };
}
