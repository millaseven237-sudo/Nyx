import { jidNormalizedUser } from '@whiskeysockets/baileys';
import { numberOf, parseJid, toUserJid } from '../lib/jidManager.js';
import { db } from '../lib/database.js';
import { getContextInfo, getQuoted } from '../lib/utils.js';

// WhatsApp peut identifier un expediteur par LID (@lid) ou par numero (@s.whatsapp.net).
// On collecte tous les identifiants possibles et on memorise la correspondance LID -> numero.
export function senderCandidates(m, sock) {
  const k = m.key || {};
  const raw = [k.participant, k.participantAlt, k.participantPn, k.remoteJidAlt, k.senderPn, !k.remoteJid?.endsWith('@g.us') ? k.remoteJid : null, m.participant]
    .filter(Boolean).map((j) => { try { return jidNormalizedUser(j); } catch { return j; } });
  if (k.fromMe && sock?.user?.id) raw.push(jidNormalizedUser(sock.user.id), sock.user.lid ? jidNormalizedUser(sock.user.lid) : null);
  const set = new Set(raw.filter(Boolean));
  // apprentissage lid -> numero
  const lid = [...set].find((j) => j.endsWith('@lid'));
  const pn = [...set].find((j) => j.endsWith('@s.whatsapp.net'));
  if (lid && pn) { db.lidmap.data.map[numberOf(lid)] = numberOf(pn); db.lidmap.save(); }
  for (const j of [...set]) { const n = db.lidmap.data.map[numberOf(j)]; if (n && j.endsWith('@lid')) set.add(toUserJid(n)); }
  return [...set];
}

export function resolveSender(m, sock) {
  const cands = senderCandidates(m, sock);
  const jid = cands.find((j) => j.endsWith('@s.whatsapp.net')) || cands[0] || m.key.remoteJid;
  return { jid, all: cands, numbers: cands.map(numberOf) };
}

export const sameUser = (a, b) => {
  if (!a || !b) return false;
  const A = Array.isArray(a) ? a : [a]; const B = Array.isArray(b) ? b : [b];
  const nums = new Set(B.map(numberOf).filter(Boolean));
  return A.some((x) => { const n = numberOf(x); return n && (nums.has(n) || nums.has(db.lidmap.data.map[n])); });
};

// Un participant de groupe peut avoir id / lid / phoneNumber
export const participantIds = (p) => [p.id, p.lid, p.phoneNumber, p.jid].filter(Boolean);
export const isAdminIn = (meta, ids) => !!meta?.participants?.some((p) => (p.admin || p.isAdmin || p.isSuperAdmin) && sameUser(participantIds(p), ids));
export const botIds = (sock) => [sock.user?.id, sock.user?.lid].filter(Boolean);

// Cibles : mentions, message cite, ou numeros dans le texte
export function extractTargets(m, args = []) {
  const ctx = getContextInfo(m.message);
  const out = new Set();
  (ctx?.mentionedJid || []).forEach((j) => out.add(j));
  const q = getQuoted(m); if (q?.sender) out.add(q.sender);
  for (const a of args) { const d = String(a).replace(/\D/g, ''); if (d.length >= 7 && d.length <= 15) out.add(toUserJid(d)); }
  return [...out];
}

export { parseJid };
