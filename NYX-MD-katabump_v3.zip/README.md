# 🌑 NYX MD — Bot WhatsApp Multi-Device

Bot WhatsApp modulaire basé sur **@whiskeysockets/baileys 7.0.0-rc14** (Node.js ≥ 20, ESM).
~130 commandes : système JID, chaînes, statuts, moteur de stickers (packs de 60), broadcast contrôlé, groupes, outils média, commande cachée **NYX**.
Le visuel du menu est `media/menu.png` (remplaçable par n'importe quelle image PNG).

## Installation

```bash
npm install
npm start
```

**Configuration : ouvrez `config.js`** et remplissez le bloc `USER_CONFIG` en haut du fichier : `OWNER_NUMBER` (votre numéro, format international sans `+`), `PAIRING_NUMBER` (numéro du bot ; vide = OWNER_NUMBER), `PREFIX`, `MODE`, clés API facultatives. Un fichier `.env` reste possible et, s'il définit une variable, il est prioritaire.
Vérification sans connexion : `npm run check` (charge toutes les commandes et détecte erreurs/doublons).

## Connexion par Pairing Code

1. Renseignez `OWNER_NUMBER` / `PAIRING_NUMBER` dans `config.js`, lancez `npm start`.
2. Un cadre violet affiche un code `XXXX-XXXX` dans la console.
3. Sur le téléphone : **WhatsApp → Appareils connectés → Connecter un appareil → Lier avec un numéro de téléphone** → saisissez le code.
4. La session est enregistrée dans `session/`. Aux démarrages suivants, plus de code.
- Session invalide / déconnectée depuis le téléphone : supprimez `session/` et relancez.
- Un verrou (`session/.lock`) empêche deux instances d'utiliser la même session.

## Déploiement Katabump (panneau type Pterodactyl)

- Startup command : `npm start` (Node ≥ 20). Fichier principal : `index.js`.
- Uploadez le projet **sans** `node_modules` (installé par le panel) ni `session/`.
- Éditez simplement `config.js` (bloc `USER_CONFIG`) dans le gestionnaire de fichiers du panel, puis redémarrez. Les fichiers doivent être à la **racine** du serveur (`index.js` visible directement).
- `ffmpeg` est fourni par le paquet `ffmpeg-static` (aucune installation système).
- `.restart` = reconnexion + rechargement des commandes sans quitter le processus ; `.restart hard` quitte avec le code 1 (le panel relance si l'auto-restart est actif). `.update` fait un `git pull` si le dossier est un dépôt git.
- Sauvegardez régulièrement `session/` et `database/`.

## Ce qui est réellement possible (et ce qui ne l'est pas)

| Fonction | Réalité |
|---|---|
| JID | Types gérés : utilisateur (`@s.whatsapp.net`), LID (`@lid`), groupe, chaîne (`@newsletter`), statut, diffusion, bot. Aucun JID n'est inventé. `.jidcheck` vérifie le **format** ; l'existence n'est testée que pour les numéros. |
| Liens de groupe | Le bot doit être admin ; commandes `.link`, `.invitelink` réservées par défaut aux admins. |
| Chaînes | Infos/JID/lien via lien de chaîne, JID ou message transféré. **L'annuaire public n'est pas accessible** : `.channelsearch` cherche seulement parmi les chaînes déjà vues. Publier/supprimer exige d'être OWNER/ADMIN de la chaîne. Statistiques = ce que WhatsApp expose (abonnés, vues et réactions des dernières publications). |
| Statuts | Uniquement les statuts **reçus** par le compte, jamais de contournement de confidentialité. Les médias doivent être téléchargés à la réception (contacts suivis avec `.statuswatch`, ou `.status download all`). Marquer « vu » est visible par l'auteur. Commandes réservées à l'owner par défaut. |
| Stickers | Création statique/animée, métadonnées (nom, auteur, emojis), packs de **60 max**. Le ZIP exporté est une **archive de sauvegarde, pas un pack natif** : WhatsApp limite un pack natif à **30 stickers** et n'autorise pas un bot à en créer. Le ZIP contient donc aussi `native-ready/part1`, `part2` (≤ 30 + `tray.png`, `title.txt`, `author.txt`) à importer via une application tierce (ex. Sticker Maker). |
| Broadcast | File d'attente avec délais aléatoires, pauses longues, quota quotidien, plafond par envoi, anti-répétition, pause/reprise/arrêt, confirmation obligatoire (`.bcgo`). Les envois privés ne visent que les gens ayant déjà écrit au bot. Le risque de restriction WhatsApp ne peut jamais être nul. `.bcstatus` publie dans **votre statut** WhatsApp. |
| `.antibot` | Heuristique limitée (identifiants de message typiques de certaines bibliothèques) : non infaillible. |
| IA / vision / transcription | Nécessitent `GEMINI_API_KEY`. Sans clé, NYX répond avec ses variantes locales et indique le type de média. |
| `.removebg` | Nécessite `REMOVEBG_API_KEY`. `.emojimix` nécessite `TENOR_API_KEY`. `.tts` utilise le service Google Translate TTS (non officiel). `.translate` utilise MyMemory (gratuit, 480 car. max). |

## Commandes (aperçu — `.menu` pour la liste complète)

- **Général** : menu, help, ping, alive, runtime, owner, profile, info, system, repo, support, report, afk, mode, public, private, restart, shutdown, update, plugins
- **JID** : jid, getjid, groupjid, link, invitelink, jidinfo, jidcheck, jidlist, groupinfo
- **Chaînes** : channel, channelinfo, channellink, channeljid, channelsearch, channelpreview, channelstats, channelreact, channelpost, channeldelete
- **Statuts** : status, getstatus, mystatus, statusview, statusreact, statusreply, statusdownload, statussave, statusprivacy, statuslist, statuswatch
- **Stickers** : sticker/s, take, rename, toimg, togif, tovideo, emojimix, stickerinfo, stickerpack, pack, packadd, packremove, packexport, packlist, packdelete
- **Broadcast** : broadcast/bc, bcgroup, bcprivate, bcchannel, bcstatus, bcall, bcgo, bccancel, broadcastlist, broadcaststop, broadcaststats
- **Groupe** : kick, add, promote, demote, tagall, hidetag, tagadmins, tagmembers, mute, unmute, lock, unlock, welcome, goodbye, setwelcome, setgoodbye, antilink, antispam, antibot, groupdesc, grouptitle, groupopen, groupclose, poll, invite, revoke
- **Média** : tomp3, toaudio, compress, resize, crop, blur, qr, readqr, tts, transcribe, translate, caption, removebg
- **Owner** : addowner, delowner, owners, setperm, allow, deny, perms, enable, disable, stats, errors, settings, setprefix, users
- **Caché** : `.nyx` (absente du menu)

### Pack de stickers
`.stickerpack DARK COLLECTION | Auteur | catégorie` → envoyez vos stickers (images/vidéos converties automatiquement) → progression `24/60` → à 60 le ZIP est généré automatiquement, ou `.stickerpack finish` pour terminer avant. `.pack select` reprend un pack, `.packexport` le réexporte.

### NYX (cachée)
Déclencheurs : mot-clé `nyx`, `.nyx`, réponse à un message du bot, ou `nyx` seul en réponse à un message pour l'analyser (texte, sticker, image, audio, vidéo).
Owner : `.nyx on|off`, `.nyx mode auto|discret|manual`, `.nyx persona dark|sweet|sarcastic|mystic`, `.nyx trigger add|del <mot>`, `.nyx cooldown <s>`, `.nyx ai on|off`.

### Permissions
Chaque commande a un niveau (`public`, `admin`, `owner`) modifiable : `.setperm <cmd> <niveau>`, `.allow` / `.deny <cmd> @user`, `.disable <cmd|catégorie>`. Les owners secondaires s'ajoutent avec `.addowner`. `.settings` modifie délais, limites, auteur de stickers, etc.

## Architecture

```
index.js            connexion, Pairing Code, reconnexion, verrou de session
config.js settings.js .env
handler/            commandHandler, messageHandler, jidHandler, permissionHandler, groupEvents
commands/<catégorie>/*.js   plugins (export default commande ou tableau de commandes)
lib/                stickerEngine, channelManager, statusManager, broadcastManager, jidManager, database, nyxEngine, ai, ui, utils
database/ session/ media/ temp/
```
Ajouter une commande : créez un fichier dans `commands/<catégorie>/` exportant `{ name, aliases, desc, usage, access, group, botAdmin, run(c) }`, puis `.plugins reload`.

## Sécurité & stabilité
Aucune clé dans le code livré (tout dans `config.js`/`.env` : ne partagez pas ce fichier une fois rempli) · permissions vérifiées avant chaque commande · erreurs capturées et journalisées (`.errors`) · reconnexion avec backoff · ffmpeg en processus enfant (2 en parallèle max, timeout) · limites de taille/durée des médias · nettoyage automatique de `temp/` · base JSON à écriture atomique.
