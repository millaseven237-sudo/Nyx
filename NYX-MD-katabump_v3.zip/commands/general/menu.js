import { commands, findCommand } from '../../handler/commandHandler.js';
import { frame, animate, sendBanner, bootFrames, CATEGORIES } from '../../lib/ui.js';
import { db, S } from '../../lib/database.js';
import { formatDuration } from '../../lib/utils.js';
import { runtime } from '../../lib/runtime.js';

const order = ['general', 'jid', 'channel', 'status', 'sticker', 'broadcast', 'group', 'media', 'owner'];

export default [
  {
    name: 'menu', aliases: ['m', 'commands'], desc: 'Affiche le menu NYX', usage: '.menu [categorie]',
    async run(c) {
      const p = c.prefix; const visible = commands.filter((x) => !x.hidden);
      const want = c.args[0]?.toLowerCase();
      await animate(c.sock, c.chat, c.m, bootFrames('Chargement du menu'), 380);
      if (want && CATEGORIES[want]) {
        const cat = CATEGORIES[want]; const list = visible.filter((x) => x.category === want);
        const lines = list.map((x) => `${cat.emoji} ${p}${x.name}${x.access === 'owner' ? ' 👑' : x.access === 'admin' ? ' 🛡️' : ''} ➤ ${x.desc || ''}`);
        return sendBanner(c.sock, c.chat, frame(`${cat.label} (${list.length})`, lines, 'NYX • .menu pour tout voir'), c.m);
      }
      const head = [`👤 Utilisateur : ${c.pushName || 'inconnu'}`, `⚡ Prefixe : ${p}   🌐 Mode : ${S().mode}`, `⏱️ Uptime : ${formatDuration(Date.now() - runtime.startedAt)}`, `📦 Commandes : ${visible.length}`, ''];
      const body = [];
      for (const k of order) {
        const list = visible.filter((x) => x.category === k); if (!list.length) continue;
        const cat = CATEGORIES[k];
        body.push(`╭─❮ ${cat.emoji} *${cat.label}* ❯`, ...list.map((x) => `│ ▫️ ${p}${x.name}`), '╰────────────', '');
      }
      body.push(`💜 ${p}menu <categorie> pour le detail`, `🔎 ${p}help <commande> pour l'aide`, `🗂️ Categories : ${order.join(', ')}`);
      return sendBanner(c.sock, c.chat, frame('MENU', [...head, ...body]), c.m);
    }
  },
  {
    name: 'help', aliases: ['aide', 'h'], desc: 'Aide detaillee d\'une commande', usage: '.help <commande>',
    async run(c) {
      const cmd = findCommand(c.args[0]?.replace(c.prefix, ''));
      if (!cmd || (cmd.hidden && !c.isOwner)) return c.reply(frame('HELP', [`Usage : ${c.prefix}help <commande>`, `Tapez ${c.prefix}menu pour la liste.`]));
      const ov = db.perms.data.commands[cmd.name] || {};
      return c.reply(frame('HELP', [`📌 ${c.prefix}${cmd.name}`, `📝 ${cmd.desc || '-'}`, `🧭 Usage : ${cmd.usage || c.prefix + cmd.name}`, cmd.aliases?.length ? `🔁 Alias : ${cmd.aliases.map((a) => c.prefix + a).join(', ')}` : null, `🔐 Acces : ${ov.level || cmd.access || 'public'}${ov.disabled ? ' (desactivee)' : ''}`, cmd.group ? '👥 Groupe uniquement' : null, cmd.botAdmin ? '🤖 Le bot doit etre admin' : null, `📂 Categorie : ${cmd.category}`]));
    }
  }
];
