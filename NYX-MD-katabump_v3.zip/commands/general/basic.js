import os from 'node:os';
import fs from 'node:fs';
import { execFile } from 'node:child_process';
import ffmpegPath from 'ffmpeg-static';
import { commands, findCommand, loadCommands, loadErrors } from '../../handler/commandHandler.js';
import { config } from '../../config.js';
import { db, S } from '../../lib/database.js';
import { frame, sendBanner, bar } from '../../lib/ui.js';
import { formatDuration, formatBytes, fmtDate } from '../../lib/utils.js';
import { runtime } from '../../lib/runtime.js';
import { extractTargets } from '../../handler/jidHandler.js';
import { numberOf } from '../../lib/jidManager.js';
import { isOwnerIds } from '../../handler/permissionHandler.js';

const uptime = () => formatDuration(Date.now() - runtime.startedAt);

export default [
  {
    name: 'ping', aliases: ['p'], desc: 'Latence du bot', async run(c) {
      const t0 = Date.now(); const ts = Number(c.m.messageTimestamp) * 1000 || t0;
      const msg = await c.reply('🌑 Ping…');
      const rtt = Date.now() - t0;
      await c.sock.sendMessage(c.chat, { text: frame('PING', [`⚡ Aller-retour : ${rtt} ms`, `📨 Reception : ${Math.max(0, t0 - ts)} ms`, `⏱️ Uptime : ${uptime()}`]), edit: msg.key });
    }
  },
  {
    name: 'alive', aliases: ['online'], desc: 'Verifie que NYX est actif', async run(c) {
      return sendBanner(c.sock, c.chat, frame('ALIVE', ['🟣 NYX MD est en ligne', `⏱️ Uptime : ${uptime()}`, `🌐 Mode : ${S().mode}`, `📦 Commandes : ${commands.filter((x) => !x.hidden).length}`, `💾 RAM : ${formatBytes(process.memoryUsage().rss)}`]), c.m);
    }
  },
  { name: 'runtime', aliases: ['uptime'], desc: 'Temps de fonctionnement', async run(c) { return c.reply(frame('RUNTIME', [`⏱️ ${uptime()}`, `🔌 Connecte depuis : ${runtime.connectedAt ? fmtDate(runtime.connectedAt) : '-'}`])); } },
  {
    name: 'owner', aliases: ['creator'], desc: 'Contact du proprietaire', async run(c) {
      if (!config.ownerNumber) return c.reply('⚠️ OWNER_NUMBER n\'est pas configure.');
      const vcard = `BEGIN:VCARD\nVERSION:3.0\nFN:${config.botName} Owner\nORG:${config.botName};\nTEL;type=CELL;type=VOICE;waid=${config.ownerNumber}:+${config.ownerNumber}\nEND:VCARD`;
      return c.send({ contacts: { displayName: `${config.botName} Owner`, contacts: [{ vcard }] } });
    }
  },
  {
    name: 'profile', aliases: ['me', 'whoami'], desc: 'Profil d\'un utilisateur', usage: '.profile [@user]', async run(c) {
      const t = extractTargets(c.m, c.args)[0] || c.sender; const n = numberOf(t);
      const u = db.users.data.list[t] || {}; let about = '-', pp = null;
      try { about = (await c.sock.fetchStatus(t))?.[0]?.status?.status || '-'; } catch {}
      try { pp = await c.sock.profilePictureUrl(t, 'image'); } catch {}
      const owner = isOwnerIds([t]);
      const adm = c.meta?.participants?.some((p) => p.admin && [p.id, p.phoneNumber, p.lid].some((x) => x && numberOf(x) === n));
      const cap = frame('PROFILE', [`👤 Nom : ${u.name || c.pushName || '-'}`, `📞 Numero : +${n}`, `🔑 JID : ${t}`, `💬 A propos : ${about}`, `👑 Role : ${owner ? 'Owner' : adm ? 'Admin du groupe' : 'Membre'}`, `✉️ Messages vus : ${u.count || 0}`, u.first ? `📅 Premiere vue : ${fmtDate(u.first)}` : null]);
      return pp ? c.send({ image: { url: pp }, caption: cap, mentions: [t] }) : c.reply(cap, { mentions: [t] });
    }
  },
  {
    name: 'info', aliases: ['botinfo'], desc: 'Informations sur NYX MD', async run(c) {
      return sendBanner(c.sock, c.chat, frame('INFO', ['🤖 Bot : ' + config.botName, '🧩 Version : 1.0.0', `⚡ Prefixe : ${S().prefix}`, `🌐 Mode : ${S().mode}`, `📦 Commandes : ${commands.filter((x) => !x.hidden).length}`, `👥 Utilisateurs : ${Object.keys(db.users.data.list).length}`, `✉️ Messages traites : ${db.stats.data.messages}`, `⏱️ Uptime : ${uptime()}`, '🛠️ Moteur : Baileys (Multi-Device)']), c.m);
    }
  },
  {
    name: 'system', aliases: ['sys'], desc: 'Etat du systeme', async run(c) {
      const mem = process.memoryUsage(); const total = os.totalmem(), free = os.freemem();
      return c.reply(frame('SYSTEM', [`🖥️ OS : ${os.type()} ${os.release()} (${os.arch()})`, `⚙️ Node : ${process.version}`, `🧠 CPU : ${os.cpus()[0]?.model?.trim() || '?'} x${os.cpus().length}`, `📈 Charge : ${os.loadavg().map((x) => x.toFixed(2)).join(' / ')}`, `💾 RAM systeme : ${bar(total - free, total)}  (${formatBytes(total - free)}/${formatBytes(total)})`, `🔹 RAM bot : ${formatBytes(mem.rss)} (heap ${formatBytes(mem.heapUsed)})`, `🎞️ ffmpeg : ${ffmpegPath ? 'disponible' : 'absent'}`, `🆔 PID : ${process.pid}`]));
    }
  },
  { name: 'repo', aliases: ['github', 'source'], desc: 'Depot du projet', async run(c) { return c.reply(config.repoUrl ? frame('REPO', [`🔗 ${config.repoUrl}`]) : '⚠️ REPO_URL n\'est pas defini dans config.js.'); } },
  { name: 'support', desc: 'Groupe de support et chaine officielle', async run(c) {
      let members = ''; if (config.groupJid) { try { const m = await c.sock.groupMetadata(config.groupJid); members = ` • ${m.participants.length} membres`; } catch {} }
      const l = [config.groupLink ? `👥 ${config.groupName}${members}\n🔗 ${config.groupLink}` : null, config.channelLink ? `📢 ${config.channelName}\n🔗 ${config.channelLink}` : null, config.supportLink ? `🔗 ${config.supportLink}` : null].filter(Boolean);
      return c.reply(l.length ? frame('SUPPORT', l) : '⚠️ Renseignez GROUP_LINK / CHANNEL_LINK dans config.js.');
    } },
  {
    name: 'report', aliases: ['bug'], desc: 'Signaler un probleme au proprietaire', usage: '.report <message>', async run(c) {
      if (!c.text) return c.reply(`Usage : ${c.prefix}report <votre message>`);
      const owners = [config.ownerNumber, ...db.owners.data.secondary].filter(Boolean);
      if (!owners.length) return c.reply('⚠️ Aucun owner configure.');
      const body = frame('REPORT', [`👤 ${c.pushName} (+${numberOf(c.sender)})`, c.isGroup ? `👥 Groupe : ${c.meta?.subject || c.chat}` : '💬 Prive', `📝 ${c.text.slice(0, 1000)}`]);
      let ok = 0; for (const o of owners) { try { await c.sock.sendMessage(`${o}@s.whatsapp.net`, { text: body }); ok++; } catch {} }
      return c.reply(ok ? '✅ Signalement transmis au proprietaire.' : '❌ Impossible de joindre le proprietaire.');
    }
  },
  {
    name: 'afk', desc: 'Passe en mode absent', usage: '.afk [raison]', async run(c) {
      db.afk.data.list[numberOf(c.sender)] = { reason: c.text.slice(0, 120), since: Date.now() }; db.afk.save();
      return c.reply(frame('AFK', [`💤 Vous etes AFK${c.text ? ` : ${c.text}` : ''}`, 'Je previendrai ceux qui vous mentionnent.']));
    }
  },
  {
    name: 'mode', access: 'owner', desc: 'Voir / changer le mode public ou prive', usage: '.mode [public|private]', async run(c) {
      const v = c.args[0]?.toLowerCase();
      if (v === 'public' || v === 'private') { S().mode = v; db.settings.save(); return c.reply(`✅ Mode ${v === 'public' ? 'PUBLIC : tout le monde peut utiliser le bot' : 'PRIVE : seuls les owners peuvent utiliser le bot'}.`); }
      return c.reply(frame('MODE', [`Mode actuel : ${S().mode}`, `${c.prefix}mode public | private`]));
    }
  },
  { name: 'public', access: 'owner', desc: 'Active le mode public', async run(c) { S().mode = 'public'; db.settings.save(); return c.reply('✅ Mode PUBLIC active.'); } },
  { name: 'private', access: 'owner', desc: 'Active le mode prive', async run(c) { S().mode = 'private'; db.settings.save(); return c.reply('🔒 Mode PRIVE active : seuls les owners sont servis.'); } },
  {
    name: 'restart', access: 'owner', desc: 'Redemarre le bot', usage: '.restart [hard]', async run(c) {
      if (c.args[0] === 'hard') { await c.reply('♻️ Redemarrage complet du processus (le panel doit le relancer)…'); return setTimeout(() => runtime.hardRestart(), 800); }
      await c.reply('♻️ Reconnexion et rechargement des commandes…');
      await loadCommands(true);
      setTimeout(() => runtime.restart().catch(() => {}), 500);
    }
  },
  { name: 'shutdown', aliases: ['stop'], access: 'owner', desc: 'Arrete le bot', async run(c) { await c.reply('🌒 NYX s\'eteint…'); setTimeout(() => runtime.shutdown(), 800); } },
  {
    name: 'update', access: 'owner', desc: 'Met a jour depuis git (si le bot est un depot git)', async run(c) {
      if (!fs.existsSync(`${config.root}/.git`)) return c.reply(frame('UPDATE', ['⚠️ Ce dossier n\'est pas un depot git.', 'Sur Katabump : liez le depot GitHub du bot, ou re-uploadez les fichiers.']));
      const run = (cmd, args) => new Promise((res) => execFile(cmd, args, { cwd: config.root, timeout: 180000 }, (e, so, se) => res({ e, out: (so || se || '').toString().trim() })));
      await c.reply('🔄 git pull…');
      const r = await run('git', ['pull', '--ff-only']);
      if (r.e) return c.reply(`❌ git pull a echoue :\n${r.out.slice(0, 600)}`);
      if (/Already up to date|deja a jour/i.test(r.out)) return c.reply('✅ Deja a jour.');
      const n = await run('npm', ['install', '--omit=dev', '--no-audit', '--no-fund']);
      await c.reply(`✅ Mise a jour appliquee${n.e ? ' (npm install a echoue : ' + n.out.slice(0, 200) + ')' : ''}.\n♻️ Redemarrage complet…`);
      setTimeout(() => runtime.hardRestart(), 1000);
    }
  },
  {
    name: 'plugins', aliases: ['plugin'], desc: 'Liste / gere les plugins (commandes)', usage: '.plugins [reload|on <cmd>|off <cmd>]', async run(c) {
      const sub = c.args[0]?.toLowerCase();
      if (sub && !c.isOwner) return c.reply('❌ Reserve au proprietaire.');
      if (sub === 'reload') { await loadCommands(true); return c.reply(`✅ ${commands.length} commandes rechargees${loadErrors.length ? `\n⚠️ Erreurs :\n${loadErrors.join('\n')}` : ''}`); }
      if (sub === 'on' || sub === 'off') {
        const cmd = findCommand(c.args[1]); if (!cmd) return c.reply('❌ Commande inconnue.');
        (db.perms.data.commands[cmd.name] ||= {}).disabled = sub === 'off'; db.perms.save(); return c.reply(`✅ ${c.prefix}${cmd.name} ${sub === 'off' ? 'desactivee' : 'activee'}.`);
      }
      const files = {}; for (const x of commands) (files[x.file] ||= []).push(x.name);
      const lines = Object.entries(files).map(([f, n]) => `📁 ${f} (${n.length}) : ${n.slice(0, 8).join(', ')}${n.length > 8 ? '…' : ''}`);
      const off = Object.entries(db.perms.data.commands).filter(([, v]) => v.disabled).map(([k]) => k);
      return c.reply(frame('PLUGINS', [...lines, '', off.length ? `⛔ Desactivees : ${off.join(', ')}` : '✅ Aucune commande desactivee']));
    }
  }
];
