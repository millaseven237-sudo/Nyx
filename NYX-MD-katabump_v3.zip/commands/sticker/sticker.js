import fs from 'node:fs';
import { S, db } from '../../lib/database.js';
import { config } from '../../config.js';
import { frame, bar } from '../../lib/ui.js';
import { findMedia, downloadBuffer, getQuoted, mediaInfo, formatBytes, fetchJson, ffmpegBuffer, sleep } from '../../lib/utils.js';
import * as se from '../../lib/stickerEngine.js';
import { finishAndSend } from '../../handler/messageHandler.js';

const EMOJI_RE = /\p{Extended_Pictographic}(?:\uFE0F|\u200D\p{Extended_Pictographic}|[\u{1F3FB}-\u{1F3FF}])*/gu;
const emojisIn = (t) => (t.match(EMOJI_RE) || []).slice(0, 8);
const splitMeta = (t) => t.replace(EMOJI_RE, ' ').replace(/--\w+/g, ' ').split('|').map((x) => x.trim()).filter((x) => x !== undefined);

function needMedia(c, kinds, hint) {
  const t = findMedia(c.m, kinds); if (!t) throw new Error(hint || 'Repondez a un media ou envoyez-le avec la commande en legende.');
  return t;
}
async function stickerFrom(c, t, opts) {
  const buf = await downloadBuffer(c.sock, t, c.logger); const i = t.info;
  if (i.kind === 'sticker') return se.retag(buf, opts);
  if (i.kind === 'video' && i.seconds > S().maxVideoSeconds) throw new Error(`Video trop longue (${i.seconds}s). Maximum : ${S().maxVideoSeconds}s.`);
  return se.makeSticker(buf, { mime: i.mime, isVideo: i.kind === 'video' || i.mime.includes('gif'), ...opts });
}
const owner = (c) => c.sender;
const getPackArg = (c, ref) => (ref ? se.findPack(owner(c), ref) : se.activePack(owner(c)));
const packLine = (p, i) => `${i + 1}. ${p.status === 'open' ? '🟢' : '✅'} ${p.name} — ${p.files.length}/${Math.min(60, S().stickerPackLimit)} [${p.category}] (${p.id})`;

export default [
  {
    name: 'sticker', aliases: ['s', 'stiker'], desc: 'Image / video / GIF -> sticker', usage: '.s [pack | auteur] [emojis] [--crop]', async run(c) {
      const t = needMedia(c, ['image', 'video', 'sticker']);
      const [pack, author] = splitMeta(c.text);
      const buf = await stickerFrom(c, t, { pack: pack || S().stickerPackName, author: author || c.pushName || S().stickerAuthor, emojis: emojisIn(c.text).length ? emojisIn(c.text) : ['✨'], crop: /--crop/.test(c.text) });
      await c.send({ sticker: buf });
      const p = se.activePack(owner(c)); if (p && p.chat === c.chat && p.status === 'open') { /* ajout automatique gere par la session */ }
    }
  },
  {
    name: 'take', aliases: ['steal'], desc: 'Prend un sticker avec votre nom', usage: '.take [pack | auteur]', async run(c) {
      const t = needMedia(c, ['sticker'], 'Repondez a un sticker.'); const [pack, author] = splitMeta(c.text);
      const buf = await se.retag(await downloadBuffer(c.sock, t, c.logger), { pack: pack || S().stickerPackName, author: author || c.pushName || S().stickerAuthor, emojis: emojisIn(c.text).length ? emojisIn(c.text) : ['✨'] });
      return c.send({ sticker: buf });
    }
  },
  {
    name: 'rename', aliases: ['stickername'], desc: 'Modifie nom / auteur / emojis d\'un sticker', usage: '.rename <pack> | <auteur> | <emojis>', async run(c) {
      const t = needMedia(c, ['sticker'], 'Repondez a un sticker.'); const raw = await downloadBuffer(c.sock, t, c.logger);
      const cur = (await se.readExif(raw)) || {}; const [pack, author] = splitMeta(c.text); const em = emojisIn(c.text);
      if (!pack && !author && !em.length) return c.reply('Usage : .rename Nom du pack | Auteur | 😎🔥');
      return c.send({ sticker: await se.retag(raw, { pack: pack || cur['sticker-pack-name'] || S().stickerPackName, author: author || cur['sticker-pack-publisher'] || S().stickerAuthor, emojis: em.length ? em : cur.emojis?.length ? cur.emojis : ['✨'] }) });
    }
  },
  {
    name: 'toimg', aliases: ['toimage'], desc: 'Sticker -> image', async run(c) {
      const t = needMedia(c, ['sticker'], 'Repondez a un sticker.'); const png = await se.stickerToPng(await downloadBuffer(c.sock, t, c.logger));
      return c.send({ image: png, caption: '🖼️ Sticker converti en image' });
    }
  },
  {
    name: 'tovideo', aliases: ['tomp4'], desc: 'Sticker anime / GIF -> video MP4', async run(c) {
      const t = needMedia(c, ['sticker', 'video'], 'Repondez a un sticker anime ou a un GIF/video.'); const buf = await downloadBuffer(c.sock, t, c.logger);
      if (t.info.kind === 'sticker') { if (!se.webpInfo(buf).animated) throw new Error('Ce sticker n\'est pas anime. Utilisez .toimg.'); return c.send({ video: await se.animatedStickerToMp4(buf), caption: '🎬 Converti en video' }); }
      const mp4 = await ffmpegBuffer(buf, '.mp4', '.mp4', (i, o) => ['-i', i, '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '28', '-c:a', 'aac', '-movflags', '+faststart', o]);
      return c.send({ video: mp4, caption: '🎬 Video re-encodee (compatible WhatsApp)' });
    }
  },
  {
    name: 'togif', desc: 'Sticker anime / video -> GIF (lecture en boucle)', async run(c) {
      const t = needMedia(c, ['sticker', 'video'], 'Repondez a un sticker anime ou a une video.'); const buf = await downloadBuffer(c.sock, t, c.logger);
      let mp4;
      if (t.info.kind === 'sticker') { if (!se.webpInfo(buf).animated) throw new Error('Ce sticker n\'est pas anime.'); mp4 = await se.animatedStickerToMp4(buf); }
      else { if (t.info.seconds > 30) throw new Error('Video trop longue pour un GIF (30 s max).'); mp4 = await ffmpegBuffer(buf, '.mp4', '.mp4', (i, o) => ['-i', i, '-an', '-vf', 'scale=trunc(iw/2)*2:trunc(ih/2)*2', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '28', '-movflags', '+faststart', o]); }
      return c.send({ video: mp4, gifPlayback: true, caption: '🎞️ GIF' });
    }
  },
  {
    name: 'emojimix', aliases: ['mix'], desc: 'Fusionne deux emojis en sticker (API Tenor requise)', usage: '.emojimix 😀+😍', async run(c) {
      if (!config.tenorKey) return c.reply('⚠️ .emojimix utilise l\'API Tenor (Google Emoji Kitchen). Ajoutez TENOR_API_KEY dans config.js (cle gratuite Google Cloud : activer "Tenor API").');
      const [a, b] = emojisIn(c.text); if (!a || !b) return c.reply('Usage : .emojimix 😀+😍');
      const q = encodeURIComponent(`${a}_${b}`);
      const j = await fetchJson(`https://tenor.googleapis.com/v2/featured?key=${config.tenorKey}&client_key=nyxmd&collection=emoji_kitchen_v5&q=${q}&contentfilter=high&media_filter=png_transparent&limit=1`);
      const url = j?.results?.[0]?.media_formats?.png_transparent?.url; if (!url) return c.reply('❌ Cette combinaison n\'existe pas dans Emoji Kitchen.');
      const img = Buffer.from(await (await fetch(url)).arrayBuffer());
      return c.send({ sticker: await se.makeSticker(img, { mime: 'image/png', pack: S().stickerPackName, author: c.pushName || S().stickerAuthor, emojis: [a, b] }) });
    }
  },
  {
    name: 'stickerinfo', aliases: ['sinfo'], desc: 'Details techniques d\'un sticker', async run(c) {
      const t = needMedia(c, ['sticker'], 'Repondez a un sticker.'); const buf = await downloadBuffer(c.sock, t, c.logger);
      const w = se.webpInfo(buf); const ex = await se.readExif(buf);
      return c.reply(frame('STICKER INFO', [`🧩 Type : ${w.animated ? 'anime' : 'statique'} (${w.format || '?'})`, `📐 Dimensions : ${w.width}x${w.height}`, `💾 Poids : ${formatBytes(buf.length)}`, `📦 Pack : ${ex?.['sticker-pack-name'] || '-'}`, `✍️ Auteur : ${ex?.['sticker-pack-publisher'] || '-'}`, `😀 Emojis : ${ex?.emojis?.join(' ') || '-'}`, `🆔 Pack ID : ${ex?.['sticker-pack-id'] || '-'}`]));
    }
  },

  /* ───────── PACKS ───────── */
  {
    name: 'stickerpack', aliases: ['sp-create', 'newpack'], desc: 'Cree un pack (60 stickers max) : chaque sticker envoye est ajoute', usage: '.stickerpack <nom> | <auteur> | <categorie>  •  finish | cancel | status | auto on/off', async run(c) {
      const sub = c.args[0]?.toLowerCase(); const act = se.activePack(owner(c));
      if (['finish', 'end', 'done', 'stop'].includes(sub)) {
        if (!act) return c.reply('Aucune session de pack en cours.'); if (!act.files.length) return c.reply('❌ Le pack est vide : envoyez au moins un sticker.');
        await c.reply(`📦 Finalisation de *${act.name}* (${act.files.length} stickers)…`); return finishAndSend(c, act);
      }
      if (sub === 'cancel') { if (!act) return c.reply('Aucune session en cours.'); delete db.packs.data.active[owner(c)]; db.packs.save(); return c.reply(`⏸️ Session fermee. Le pack *${act.name}* (${act.files.length}) est conserve : ${c.prefix}pack select ${act.id}`); }
      if (sub === 'status' || (!c.text && act)) { if (!act) return c.reply(`Aucune session. Lancez : ${c.prefix}stickerpack Mon Pack`); return c.reply(se.progressText(act) + `\n${bar(act.files.length, 60)}\nEnvoyez le prochain sticker.`); }
      if (sub === 'auto') { if (!act) return c.reply('Aucune session en cours.'); act.auto = c.args[1] !== 'off'; db.packs.save(); return c.reply(`✅ Conversion auto des images/videos envoyees : ${act.auto ? 'on' : 'off'}.`); }
      if (act) return c.reply(`⚠️ Une session est deja ouverte (*${act.name}*, ${act.files.length}/60). Terminez-la : ${c.prefix}stickerpack finish`);
      if (se.userPacks(owner(c)).length >= 30) return c.reply('❌ Limite de 30 packs atteinte. Supprimez-en avec .packdelete.');
      const [name, author, category] = c.text.split('|').map((x) => x.trim());
      const pack = se.createPack({ owner: owner(c), name: name || `Pack ${se.userPacks(owner(c)).length + 1}`, author: author || c.pushName || S().stickerAuthor, category: category || 'general' });
      pack.chat = c.chat; pack.auto = true; pack.emojis = ['✨']; db.packs.save();
      return c.reply(se.progressText(pack) + `\nEnvoyez vos stickers (les images/videos sont converties automatiquement).\n${c.prefix}stickerpack finish pour terminer • cancel pour mettre en pause.`);
    }
  },
  {
    name: 'pack', desc: 'Gestion des packs', usage: '.pack select|category|rename|author|show|send <pack> ...', async run(c) {
      const sub = c.args[0]?.toLowerCase(); const rest = c.args.slice(1);
      if (!sub) { const act = se.activePack(owner(c)); return c.reply(frame('PACK', [act ? `🟢 Session : ${act.name} (${act.files.length}/60)` : 'Aucune session active.', '', `${c.prefix}stickerpack <nom>  creer`, `${c.prefix}pack select <pack>  reprendre`, `${c.prefix}pack category <pack> <cat>`, `${c.prefix}pack rename <pack> <nouveau nom>`, `${c.prefix}pack author <pack> <auteur>`, `${c.prefix}pack show <pack> [n]`, `${c.prefix}pack send <pack>`, `${c.prefix}packlist  ${c.prefix}packadd  ${c.prefix}packremove`, `${c.prefix}packexport  ${c.prefix}packdelete`])); }
      const pack = se.findPack(owner(c), rest[0]); if (!pack) return c.reply('❌ Pack introuvable. Voir .packlist');
      if (sub === 'select') { if (pack.status !== 'open') return c.reply('ℹ️ Ce pack est termine. Utilisez .packadd pour y ajouter (si < 60) apres l\'avoir rouvert : .pack reopen'); pack.chat = c.chat; pack.auto ??= true; db.packs.data.active[owner(c)] = pack.id; db.packs.save(); return c.reply(se.progressText(pack) + '\nSession reprise. Envoyez le prochain sticker.'); }
      if (sub === 'reopen') { if (pack.files.length >= 60) return c.reply('❌ Pack deja a 60/60.'); pack.status = 'open'; db.packs.save(); return c.reply('✅ Pack rouvert. Utilisez .pack select.'); }
      if (sub === 'category') { pack.category = rest.slice(1).join(' ').slice(0, 24) || 'general'; db.packs.save(); return c.reply(`✅ Categorie : ${pack.category}`); }
      if (sub === 'rename') { const n = rest.slice(1).join(' ').slice(0, 40); if (!n) return c.reply('Usage : .pack rename <pack> <nouveau nom>'); pack.name = n; db.packs.save(); return c.reply(`✅ Renomme : ${n}\n(Les metadonnees des stickers deja ajoutes gardent l'ancien nom jusqu'a leur reexport.)`); }
      if (sub === 'author') { const n = rest.slice(1).join(' ').slice(0, 40); if (!n) return c.reply('Usage : .pack author <pack> <auteur>'); pack.author = n; db.packs.save(); return c.reply(`✅ Auteur : ${n}`); }
      if (sub === 'show') { const i = Number(rest[1]) || 1; if (!pack.files[i - 1]) return c.reply(`❌ Sticker ${i} inexistant (1-${pack.files.length}).`); return c.send({ sticker: se.readPackSticker(pack, i - 1) }); }
      if (sub === 'send') { if (!pack.files.length) return c.reply('Pack vide.'); await c.reply(`📤 Envoi de ${pack.files.length} sticker(s)…`); for (let i = 0; i < pack.files.length; i++) { await c.sock.sendMessage(c.chat, { sticker: se.readPackSticker(pack, i) }); await sleep(1200); } return; }
      return c.reply('❌ Sous-commande inconnue. Tapez .pack');
    }
  },
  {
    name: 'packadd', desc: 'Ajoute un sticker (ou image/video) a un pack', usage: '.packadd [pack]  (en repondant a un sticker)', async run(c) {
      const pack = getPackArg(c, c.args[0]); if (!pack) return c.reply('❌ Aucun pack : precisez-le ou ouvrez une session (.stickerpack).');
      if (pack.files.length >= 60) throw new Error('Pack complet (60/60).');
      const t = needMedia(c, ['sticker', 'image', 'video']); let buf = await downloadBuffer(c.sock, t, c.logger);
      if (t.info.kind !== 'sticker') buf = await se.mediaToWebp(buf, { mime: t.info.mime, isVideo: t.info.kind === 'video' });
      const n = await se.addToPack(pack, buf, emojisIn(c.text).length ? emojisIn(c.text) : pack.emojis || ['✨']);
      return c.reply(se.progressText(pack) + (n >= 60 ? '\n🎉 Pack complet !' : ''));
    }
  },
  {
    name: 'packremove', aliases: ['packrm'], desc: 'Retire un sticker d\'un pack', usage: '.packremove <numero> [pack]', async run(c) {
      const n = Number(c.args[0]); const pack = getPackArg(c, c.args[1]); if (!n || !pack) return c.reply('Usage : .packremove <numero> [pack]');
      se.removeFromPack(pack, n); return c.reply(`🗑️ Sticker ${n} retire.\n` + se.progressText(pack));
    }
  },
  {
    name: 'packexport', aliases: ['packzip'], desc: 'Exporte un pack en ZIP', usage: '.packexport [pack]', async run(c) {
      const pack = getPackArg(c, c.args[0]) || se.userPacks(owner(c)).at(-1); if (!pack) return c.reply('❌ Aucun pack.');
      await c.reply(`📦 Creation du ZIP de *${pack.name}*…`);
      const zip = await se.exportZip(pack);
      try { await c.send({ document: fs.readFileSync(zip), mimetype: 'application/zip', fileName: `${pack.name.replace(/[^\w-]+/g, '_')}_${pack.files.length}stickers.zip`, caption: `📦 ${pack.name} • ${pack.files.length} stickers\nℹ️ Archive de sauvegarde (pas un pack natif WhatsApp). Voir LISEZ-MOI.txt dans le ZIP.` }); } finally { fs.unlinkSync(zip); }
    }
  },
  {
    name: 'packlist', aliases: ['packs'], desc: 'Liste vos packs par categorie', usage: '.packlist [all]', async run(c) {
      const all = c.args[0] === 'all' && c.isOwner; const list = all ? Object.values(db.packs.data.list) : se.userPacks(owner(c));
      if (!list.length) return c.reply(`Aucun pack. Creez-en un : ${c.prefix}stickerpack Mon Pack`);
      const cats = {}; list.forEach((p, i) => (cats[p.category] ||= []).push(packLine(p, i)));
      return c.reply(frame(`PACKS (${list.length})`, Object.entries(cats).flatMap(([k, v]) => [`🗂️ *${k}*`, ...v, ''])));
    }
  },
  {
    name: 'packdelete', aliases: ['packdel'], desc: 'Supprime un pack', usage: '.packdelete <pack> [confirm]', async run(c) {
      const pack = c.isOwner && c.args[0] ? (se.findPack(owner(c), c.args[0]) || db.packs.data.list[c.args[0]]) : se.findPack(owner(c), c.args[0]);
      if (!pack) return c.reply('❌ Pack introuvable.');
      if (c.args[1] !== 'confirm') return c.reply(`⚠️ Supprimer *${pack.name}* (${pack.files.length} stickers) ? Confirmez : ${c.prefix}packdelete ${pack.id} confirm`);
      se.deletePack(pack); return c.reply(`🗑️ Pack *${pack.name}* supprime.`);
    }
  }
];
