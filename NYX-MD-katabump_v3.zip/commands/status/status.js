import fs from 'node:fs';
import path from 'node:path';
import { jidNormalizedUser } from '@whiskeysockets/baileys';
import { config } from '../../config.js';
import { db, S } from '../../lib/database.js';
import { frame } from '../../lib/ui.js';
import { extractTargets } from '../../handler/jidHandler.js';
import { numberOf, toUserJid } from '../../lib/jidManager.js';
import * as sm from '../../lib/statusManager.js';
import { findMedia, downloadBuffer, fmtDate } from '../../lib/utils.js';

const NOTE = 'ℹ️ Seuls les statuts effectivement recus par ce compte sont visibles (respect de la confidentialite).';
const keyOf = (it) => ({ remoteJid: 'status@broadcast', id: it.id, participant: it.author, fromMe: false });
const idxArg = (c) => { const a = c.args.find((x) => /^\d{1,2}$/.test(x)); return a ? Number(a) : null; };
const ICON = { image: '🖼️', video: '🎬', audio: '🎧', text: '💬' };

function contact(c) {
  const j = extractTargets(c.m, c.args)[0]; if (!j) throw new Error('Precisez un contact : mention, reponse a son message ou numero. Ex : .getstatus 237xxxxxxxxx');
  return { jid: j, num: db.lidmap.data.map[numberOf(j)] || numberOf(j), name: sm.contactName(j) };
}
function pickItems(c, who) {
  const items = sm.itemsOf(who.num); if (!items.length) throw new Error(`Aucun statut recu de ${who.name} (+${who.num}) pour le moment.`);
  const i = idxArg(c); if (i) { if (!items[i - 1]) throw new Error(`Index invalide (1-${items.length}).`); return [items[i - 1]]; }
  return items;
}
async function sendItem(c, it, label = '') {
  const cap = `🟣 ${sm.contactName(it.author)} • ${fmtDate(it.ts)}${it.text ? `\n💬 ${it.text}` : ''}${label}`;
  if (it.kind === 'text') return c.reply(cap);
  const file = await sm.ensureFile(c.sock, it, c.logger);
  const buf = fs.readFileSync(file);
  if (it.kind === 'image') return c.send({ image: buf, caption: cap });
  if (it.kind === 'video') return c.send({ video: buf, caption: cap });
  if (it.kind === 'audio') { await c.reply(cap); return c.send({ audio: buf, mimetype: it.mime || 'audio/ogg; codecs=opus' }); }
  return c.reply(cap + '\n(type non supporte pour l\'envoi)');
}

export default [
  {
    name: 'status', aliases: ['st'], access: 'owner', desc: 'Vue d\'ensemble du systeme de statuts', usage: '.status [download watch|all|off | notify on|off | read on|off]', async run(c) {
      const [k, v] = c.args.map((x) => x.toLowerCase());
      if (k === 'download' && ['watch', 'all', 'off'].includes(v)) { sm.cfg().download = v; db.status.save(); return c.reply(`✅ Telechargement automatique des statuts : ${v === 'watch' ? 'contacts suivis seulement' : v === 'all' ? 'TOUS les contacts (attention au stockage)' : 'desactive'}.`); }
      if (k === 'notify' && ['on', 'off'].includes(v)) { sm.cfg().notify = v === 'on'; db.status.save(); return c.reply(`✅ Notifications des contacts suivis : ${v}.`); }
      if (k === 'read' && ['on', 'off'].includes(v)) { S().autoReadStatus = v === 'on'; db.settings.save(); return c.reply(`✅ Lecture automatique des statuts : ${v}. ${v === 'on' ? '⚠️ Les auteurs voient que vous avez vu leur statut.' : ''}`); }
      const groups = sm.byContact(); const total = groups.reduce((a, g) => a + g.items.length, 0);
      return c.reply(frame('STATUS SYSTEM', [`👥 Contacts avec statuts : ${groups.length}`, `🟣 Statuts conserves : ${total}`, `⭐ Contacts suivis : ${db.status.data.watch.length}`, `⬇️ Telechargement auto : ${sm.cfg().download}`, `🔔 Notifications : ${sm.cfg().notify ? 'on' : 'off'}`, `👁️ Lecture auto : ${S().autoReadStatus ? 'on' : 'off'}`, '', `${c.prefix}statuslist  ${c.prefix}getstatus  ${c.prefix}statuswatch`, `${c.prefix}statusview  ${c.prefix}statusreact  ${c.prefix}statusreply`, `${c.prefix}statusdownload  ${c.prefix}statussave  ${c.prefix}statusprivacy`, '', NOTE]));
    }
  },
  {
    name: 'statuslist', aliases: ['sl'], access: 'owner', desc: 'Statuts classes par contact', async run(c) {
      const groups = sm.byContact(); if (!groups.length) return c.reply(frame('STATUS LIST', ['Aucun statut recu pour le moment.', NOTE]));
      const lines = groups.slice(0, 25).flatMap((g) => [`${g.watched ? '⭐' : '👤'} *${g.name}* (+${g.num}) — ${g.items.length}`, ...g.items.slice(0, 6).map((it, i) => `   ${i + 1}. ${ICON[it.kind] || '📎'} ${fmtDate(it.ts)}${it.file ? ' 💾' : ''}${it.text ? ' • ' + it.text.slice(0, 30) : ''}`), '']);
      return c.reply(frame(`STATUS LIST (${groups.length})`, [...lines, '💾 = media deja telecharge']));
    }
  },
  {
    name: 'getstatus', aliases: ['gs'], access: 'owner', desc: 'Recupere les statuts d\'un contact', usage: '.getstatus <@user|numero> [n]', async run(c) {
      const who = contact(c); const items = pickItems(c, who).slice(0, 8);
      await c.reply(`🟣 ${items.length} statut(s) de *${who.name}*…`);
      for (const [i, it] of items.entries()) { try { await sendItem(c, it, items.length > 1 ? `\n#${i + 1}/${items.length}` : ''); } catch (e) { await c.reply(`⚠️ #${i + 1} : ${e.message}`); } }
    }
  },
  {
    name: 'mystatus', aliases: ['ms'], access: 'owner', desc: 'Liste vos statuts / publie un statut', usage: '.mystatus  |  .mystatus <texte>  |  (media) .mystatus [legende]', async run(c) {
      const media = findMedia(c.m, ['image', 'video']);
      if (!c.text && !media) {
        const mine = sm.myItems(); return c.reply(frame('MY STATUS', mine.length ? mine.map((it, i) => `${i + 1}. ${ICON[it.kind] || '📎'} ${fmtDate(it.ts)}${it.text ? ' • ' + it.text.slice(0, 40) : ''}`) : ['Aucun statut publie recemment depuis ce compte.', `${c.prefix}mystatus <texte> pour publier un statut texte.`, 'Repondez a une image/video avec .mystatus pour publier un media.']));
      }
      const me = jidNormalizedUser(c.sock.user.id);
      const audience = [...new Set([me, ...Object.entries(db.users.data.list).filter(([j, u]) => u.dm && j.endsWith('@s.whatsapp.net')).map(([j]) => j)])];
      const opts = { statusJidList: audience };
      if (media) { const buf = await downloadBuffer(c.sock, media, c.logger); await c.sock.sendMessage('status@broadcast', { [media.info.kind]: buf, caption: c.text }, opts); }
      else await c.sock.sendMessage('status@broadcast', { text: c.text, backgroundColor: '#3b1c6e', font: 3 }, opts);
      return c.reply(`✅ Statut publie (visible par ${audience.length - 1} contact(s) connu(s) du bot, selon vos reglages de confidentialite).`);
    }
  },
  {
    name: 'statusview', aliases: ['sv'], access: 'owner', desc: 'Marque les statuts comme vus', usage: '.statusview <@user|numero|all>', async run(c) {
      let items;
      if (c.args[0]?.toLowerCase() === 'all') items = sm.byContact().flatMap((g) => g.items);
      else items = pickItems(c, contact(c));
      if (!items.length) return c.reply('Aucun statut a marquer.');
      await c.sock.readMessages(items.slice(0, 100).map(keyOf));
      return c.reply(`👁️ ${Math.min(items.length, 100)} statut(s) marque(s) comme vus.\n⚠️ Les auteurs peuvent voir que vous les avez consultes (si les accuses de lecture sont actifs).`);
    }
  },
  {
    name: 'statusreact', aliases: ['sr'], access: 'owner', desc: 'Reagit a un statut', usage: '.statusreact <emoji> <@user|numero> [n]', async run(c) {
      const emoji = c.args.find((a) => /\p{Extended_Pictographic}/u.test(a)); if (!emoji) return c.reply('Usage : .statusreact 💜 <@user|numero> [n]');
      const who = contact({ ...c, args: c.args.filter((a) => a !== emoji), m: c.m }); const it = pickItems({ ...c, args: c.args.filter((a) => a !== emoji) }, who)[0];
      await c.sock.sendMessage('status@broadcast', { react: { text: emoji, key: keyOf(it) } }, { statusJidList: [it.author, jidNormalizedUser(c.sock.user.id)] });
      return c.reply(`✅ Reaction ${emoji} envoyee au statut de *${who.name}*.`);
    }
  },
  {
    name: 'statusreply', aliases: ['srp'], access: 'owner', desc: 'Repond a un statut', usage: '.statusreply <@user|numero> <message>', async run(c) {
      const who = contact(c); const text = c.args.filter((a) => !(/^\d{7,15}$/.test(a.replace(/\D/g, '')) && a.replace(/\D/g, '') === who.num) && !a.startsWith('@')).join(' ').trim();
      if (!text) return c.reply('Usage : .statusreply <@user|numero> <votre message>');
      const it = sm.itemsOf(who.num)[0]; if (!it) return c.reply(`Aucun statut recu de ${who.name}.`);
      const raw = sm.rawMessage(it.id);
      const quoted = raw || { key: keyOf(it), message: { conversation: it.text || `[statut ${it.kind}]` } };
      await c.sock.sendMessage(toUserJid(who.num), { text }, { quoted });
      return c.reply(`✅ Reponse envoyee a *${who.name}* (en citant son statut).`);
    }
  },
  {
    name: 'statusdownload', aliases: ['sd'], access: 'owner', desc: 'Telecharge les statuts d\'un contact', usage: '.statusdownload <@user|numero> [n|all]', async run(c) {
      const who = contact(c); const items = pickItems(c, who).filter((i) => i.kind !== 'text');
      if (!items.length) return c.reply('Aucun statut media a telecharger.');
      let ok = 0; for (const it of items.slice(0, 10)) { try { await sendItem(c, it); ok++; } catch (e) { await c.reply(`⚠️ ${e.message}`); } }
      return c.reply(`✅ ${ok} statut(s) envoye(s).`);
    }
  },
  {
    name: 'statussave', aliases: ['ss'], access: 'owner', desc: 'Sauvegarde durablement les statuts d\'un contact', usage: '.statussave <@user|numero> [n]', async run(c) {
      const who = contact(c); const items = pickItems(c, who); let n = 0; const dir = path.join(config.paths.saved, who.num); fs.mkdirSync(dir, { recursive: true });
      for (const it of items.slice(0, 20)) {
        try {
          if (it.kind === 'text') { fs.writeFileSync(path.join(dir, `${it.ts}_${it.id}.txt`), it.text || ''); }
          else { const f = await sm.ensureFile(c.sock, it, c.logger); fs.copyFileSync(f, path.join(dir, path.basename(f))); }
          it.saved = true; n++;
        } catch (e) { await c.reply(`⚠️ ${e.message}`); }
      }
      db.status.save(); return c.reply(`💾 ${n} statut(s) sauvegarde(s) dans media/saved/${who.num}/ (non supprimes par le nettoyage automatique).`);
    }
  },
  {
    name: 'statusprivacy', aliases: ['sp'], access: 'owner', desc: 'Parametres de confidentialite du compte', async run(c) {
      const p = await c.sock.fetchPrivacySettings(true);
      const L = { all: 'Tout le monde', contacts: 'Mes contacts', contact_blacklist: 'Mes contacts sauf…', none: 'Personne', match_last_seen: 'Comme derniere connexion' };
      const f = (k) => L[p?.[k]] || p?.[k] || '?';
      return c.reply(frame('STATUS PRIVACY', [`🟣 Qui voit mes statuts : ${f('status')}`, `👁️ Accuses de lecture : ${p?.readreceipts === 'all' ? 'actives' : p?.readreceipts || '?'}`, `🖼️ Photo de profil : ${f('profile')}`, `🕒 Derniere connexion : ${f('last')}`, `🟢 En ligne : ${f('online')}`, `👥 Ajout aux groupes : ${f('groupadd')}`, '', '🔐 NYX respecte ces reglages : aucun contournement de visibilite.', 'Modifiez-les dans WhatsApp > Parametres > Confidentialite.']));
    }
  },
  {
    name: 'statuswatch', aliases: ['closefriends', 'sw'], access: 'owner', desc: 'Suivi des contacts proches (telechargement + notification)', usage: '.statuswatch add|del|list <@user|numero>', async run(c) {
      const sub = c.args[0]?.toLowerCase();
      if (!sub || sub === 'list') { const w = db.status.data.watch; return c.reply(frame(`CONTACTS SUIVIS (${w.length})`, w.length ? w.map((n) => `⭐ ${sm.contactName(toUserJid(n))} (+${n}) — ${sm.itemsOf(n).length} statut(s)`) : ['Aucun contact suivi.', `${c.prefix}statuswatch add <@user|numero>`])); }
      if (!['add', 'del'].includes(sub)) return c.reply('Usage : .statuswatch add|del|list <@user|numero>');
      const t = extractTargets(c.m, c.args.slice(1)); if (!t.length) return c.reply('Precisez un contact.');
      for (const j of t) sm.watch(db.lidmap.data.map[numberOf(j)] || numberOf(j), sub === 'add');
      return c.reply(`✅ ${t.length} contact(s) ${sub === 'add' ? 'ajoute(s) au suivi : leurs statuts seront telecharges et vous serez notifie' : 'retire(s) du suivi'}.`);
    }
  }
];
