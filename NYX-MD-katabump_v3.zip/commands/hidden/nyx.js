import { db, S } from '../../lib/database.js';
import { frame } from '../../lib/ui.js';
import * as nyx from '../../lib/nyxEngine.js';
import { aiReady } from '../../lib/ai.js';

// Commande CACHEE : categorie "hidden" -> absente de .menu et de .help pour les non-owners
export default [
  {
    name: 'nyx', aliases: ['nyxai'], desc: 'NYX (cachee)', usage: '.nyx [texte] | repondre a un message | .nyx on|off|mode|persona|trigger|cooldown|ai (owner)',
    async run(c) {
      const sub = c.args[0]?.toLowerCase(); const n = S().nyx;
      const adminSubs = ['on', 'off', 'mode', 'persona', 'trigger', 'cooldown', 'ai', 'status'];
      if (adminSubs.includes(sub)) {
        if (!c.isOwner) return c.reply('🌑 …');
        if (sub === 'on' || sub === 'off') { n.enabled = sub === 'on'; db.settings.save(); return c.reply(`🌑 NYX ${n.enabled ? 'reveillee' : 'endormie'}.`); }
        if (sub === 'mode') { const v = c.args[1]?.toLowerCase(); if (!['auto', 'discret', 'manual'].includes(v)) return c.reply('Modes : auto (mot-cle + reponses) • discret (reponses breves, prive/owner) • manual (uniquement .nyx)'); n.mode = v; db.settings.save(); return c.reply(`🌑 Mode : ${v}`); }
        if (sub === 'persona') { const v = c.args[1]?.toLowerCase(); if (!nyx.PERSONAS[v]) return c.reply(`Personnalites : ${Object.entries(nyx.PERSONAS).map(([k, p]) => `${k} (${p.label})`).join(', ')}`); n.persona = v; db.settings.save(); return c.reply(`🌑 Personnalite : ${nyx.PERSONAS[v].label}`); }
        if (sub === 'cooldown') { const v = Number(c.args[1]); if (!(v >= 0 && v <= 3600)) return c.reply('Usage : .nyx cooldown <secondes 0-3600>'); n.cooldownSec = v; db.settings.save(); return c.reply(`🌑 Cooldown : ${v}s`); }
        if (sub === 'ai') { const v = c.args[1]?.toLowerCase(); if (!['on', 'off'].includes(v)) return c.reply(`IA : ${n.ai ? 'on' : 'off'} (cle Gemini : ${aiReady() ? 'presente' : 'absente'})`); if (v === 'on' && !aiReady()) return c.reply('⚠️ GEMINI_API_KEY manquante dans config.js.'); n.ai = v === 'on'; db.settings.save(); return c.reply(`🌑 IA : ${v}`); }
        if (sub === 'trigger') {
          const act = c.args[1]?.toLowerCase(); const w = c.args.slice(2).join(' ').toLowerCase().trim();
          if (act === 'add' && w) { if (!n.triggers.includes(w)) n.triggers.push(w); db.settings.save(); return c.reply(`🌑 Declencheur ajoute : ${w}`); }
          if (act === 'del' && w) { if (w === 'nyx') return c.reply('Le declencheur « nyx » est permanent.'); n.triggers = n.triggers.filter((x) => x !== w); db.settings.save(); return c.reply(`🌑 Declencheur retire : ${w}`); }
          return c.reply(`Declencheurs : ${n.triggers.join(', ')}\n.nyx trigger add|del <mot>`);
        }
        return c.reply(frame('NYX', [`etat : ${n.enabled ? 'on' : 'off'}`, `mode : ${n.mode}`, `persona : ${n.persona}`, `cooldown : ${n.cooldownSec}s`, `ia : ${n.ai ? 'on' : 'off'} (cle ${aiReady() ? 'ok' : 'absente'})`, `declencheurs : ${n.triggers.join(', ')}`]));
      }
      if (!n.enabled && !c.isOwner) return;
      if (nyx.onCooldown(`cmd:${c.chat}:${c.sender}`, c.isOwner)) return;
      // Cible : message cite si present, sinon le texte donne a la commande
      const target = c.quoted && !c.text ? { key: c.quoted.key, message: c.quoted.message } : { key: c.m.key, message: c.m.message };
      const r = await nyx.reply({ sock: c.sock, target, logger: c.logger, silent: false });
      if (r?.text) await c.reply(r.text);
    }
  }
];
