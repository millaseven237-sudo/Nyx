import { frame } from '../../lib/ui.js';
import { config } from '../../config.js';
import { db } from '../../lib/database.js';
import { resolve, metadata, fetchPosts, findChannelRef } from '../../lib/channelManager.js';
import { findJidInText, isNewsletter } from '../../lib/jidManager.js';
import { fmtDate, findMedia, downloadBuffer, getText, getQuoted } from '../../lib/utils.js';

const NOTE = 'ℹ️ Baileys ne peut lire que les chaines accessibles au compte (par lien, JID, message transfere).';
const card = (m) => [`📢 *${m.name}* ${m.verified ? '✔️' : ''}`, `🔑 ${m.id}`, m.link ? `🔗 ${m.link}` : '🔗 Lien public indisponible', `👥 Abonnes : ${m.subscribers.toLocaleString('fr-FR')}`, m.created ? `📅 Creation : ${fmtDate(m.created * 1000)}` : null, m.role ? `🎭 Role du compte : ${m.role}` : null, m.state ? `📶 Etat : ${m.state}` : null, m.description ? `📝 ${m.description.slice(0, 400)}` : null];
const known = () => Object.values(db.channels.data.known);

// Cible : JID explicite en premier argument, sinon resolution classique
async function target(c, args = c.args) {
  const j = findJidInText(args[0] || ''); if (j && isNewsletter(j)) return { jid: j, meta: await metadata(c.sock, { jid: j }) };
  const { ref, meta } = await resolve(c.sock, c.m, args); return { ref, jid: meta.id, meta };
}

export default [
  {
    name: 'channel', aliases: ['newsletter', 'chaine'], desc: 'Gestion des chaines (infos, follow, liste)', usage: '.channel [follow|unfollow|mute|unmute] <lien|jid>', async run(c) {
      const sub = c.args[0]?.toLowerCase();
      if (['follow', 'unfollow', 'mute', 'unmute'].includes(sub)) {
        if (!c.isOwner) return c.reply('❌ Reserve au proprietaire.');
        const { jid, meta } = await target(c, c.args.slice(1));
        const fn = { follow: 'newsletterFollow', unfollow: 'newsletterUnfollow', mute: 'newsletterMute', unmute: 'newsletterUnmute' }[sub];
        await c.sock[fn](jid); return c.reply(`✅ ${sub} effectue sur *${meta.name}*.`);
      }
      if (c.args.length || findChannelRef(c.m, [])) { const { meta } = await resolve(c.sock, c.m, c.args); return c.reply(frame('CHANNEL', card(meta))); }
      if (config.channelJid && !c.args.length) { try { const { meta } = { meta: await metadata(c.sock, { jid: config.channelJid }) }; return c.reply(frame('MA CHAINE', card(meta))); } catch {} }
      const list = known();
      return c.reply(frame('CHANNELS', [...(list.length ? list.slice(0, 15).map((k) => `📢 ${k.name} • ${k.role || 'abonne'}\n   ${k.id}`) : ['Aucune chaine memorisee.']), '', `${c.prefix}channelinfo <lien>  ${c.prefix}channeljid  ${c.prefix}channelpreview`, `${c.prefix}channelstats  ${c.prefix}channelreact  ${c.prefix}channelpost`, NOTE]));
    }
  },
  { name: 'channelinfo', aliases: ['cinfo'], desc: 'Informations sur une chaine', usage: '.channelinfo <lien|jid> (ou citer un message transfere de la chaine)', async run(c) { const { meta } = await resolve(c.sock, c.m, c.args); return c.reply(frame('CHANNEL INFO', card(meta))); } },
  {
    name: 'channeljid', aliases: ['cjid'], desc: 'JID d\'une chaine', usage: '.channeljid <lien> | citer un message de chaine', async run(c) {
      const { meta } = await resolve(c.sock, c.m, c.args);
      return c.reply(frame('CHANNEL JID', [`📢 ${meta.name}`, `🔑 ${meta.id}`]));
    }
  },
  {
    name: 'channellink', aliases: ['clink'], desc: 'Lien de partage d\'une chaine', async run(c) {
      const { meta } = await resolve(c.sock, c.m, c.args);
      return c.reply(frame('CHANNEL LINK', [`📢 ${meta.name}`, meta.link ? `🔗 ${meta.link}` : '⚠️ Aucun lien public renvoye par WhatsApp pour cette chaine (chaine privee ou non accessible).']));
    }
  },
  {
    name: 'channelsearch', aliases: ['csearch'], desc: 'Recherche parmi les chaines connues du bot', usage: '.channelsearch <texte|lien>', async run(c) {
      if (!c.text) return c.reply('Usage : .channelsearch <nom>  ou  .channelsearch <lien de chaine>');
      if (findChannelRef(c.m, c.args)) { const { meta } = await resolve(c.sock, c.m, c.args); return c.reply(frame('CHANNEL SEARCH', card(meta))); }
      const q = c.text.toLowerCase(); const res = known().filter((k) => k.name?.toLowerCase().includes(q) || k.id.includes(q));
      return c.reply(frame(`CHANNEL SEARCH (${res.length})`, [...(res.length ? res.slice(0, 15).map((k) => `📢 ${k.name}\n   ${k.id}${k.invite ? `\n   https://whatsapp.com/channel/${k.invite}` : ''}`) : ['Aucun resultat dans les chaines connues.']), '', '⚠️ L\'annuaire public de WhatsApp n\'est pas accessible via Baileys : seules les chaines deja vues par le bot (liens, JID, transferts) sont recherchables.']));
    }
  },
  {
    name: 'channelpreview', aliases: ['cpreview'], desc: 'Apercu des dernieres publications', usage: '.channelpreview [lien|jid] [nombre]', async run(c) {
      const n = Math.min(10, Math.max(1, Number([...c.args].reverse().find((a) => /^\d{1,2}$/.test(a))) || 5));
      const { jid, meta } = await target(c);
      const posts = await fetchPosts(c.sock, jid, n);
      if (!posts.length) return c.reply(frame('CHANNEL PREVIEW', [`📢 ${meta.name}`, 'Aucune publication recuperable (historique non expose a ce compte ?).']));
      return c.reply(frame(`PREVIEW • ${meta.name}`, posts.slice(0, n).flatMap((p) => [`🆔 #${p.serverId} • ${p.kind.replace('Message', '')}${p.ts ? ` • ${fmtDate(p.ts * 1000)}` : ''}`, p.text ? `   💬 ${p.text.slice(0, 160)}` : null, `   👁️ ${p.views ?? '?'}  ${p.reactions.map((r) => `${r.code}${r.count}`).join(' ')}`, ''])));
    }
  },
  {
    name: 'channelstats', aliases: ['cstats'], desc: 'Statistiques accessibles d\'une chaine', async run(c) {
      const { jid, meta } = await target(c);
      const lines = [`📢 ${meta.name}`, `👥 Abonnes : ${meta.subscribers.toLocaleString('fr-FR')}`];
      try { const posts = await fetchPosts(c.sock, jid, 10); const views = posts.map((p) => p.views).filter((v) => v !== null);
        if (posts.length) { lines.push(`📰 Publications analysees : ${posts.length}`); if (views.length) lines.push(`👁️ Vues moyennes : ${Math.round(views.reduce((a, b) => a + b, 0) / views.length)}  (max ${Math.max(...views)})`);
          const tot = {}; posts.forEach((p) => p.reactions.forEach((r) => (tot[r.code] = (tot[r.code] || 0) + r.count)));
          const top = Object.entries(tot).sort((a, b) => b[1] - a[1]).slice(0, 5); if (top.length) lines.push(`😀 Reactions : ${top.map(([k, v]) => `${k}${v}`).join(' ')}`); }
      } catch (e) { lines.push(`⚠️ Publications indisponibles (${e.message})`); }
      if (['OWNER', 'ADMIN'].includes(meta.role)) { try { lines.push(`🛡️ Admins : ${await c.sock.newsletterAdminCount(jid)}`); } catch {} }
      lines.push('', '📌 Seules les donnees exposees par WhatsApp a ce compte sont affichees.');
      return c.reply(frame('CHANNEL STATS', lines));
    }
  },
  {
    name: 'channelreact', aliases: ['creact'], access: 'owner', desc: 'Reagit a une publication de chaine', usage: '.channelreact <emoji> [id_publication] [lien|jid]', async run(c) {
      const emoji = c.args.find((a) => /\p{Extended_Pictographic}/u.test(a)); if (!emoji) return c.reply('Usage : .channelreact 👍 [id] [lien] (ou citez un message transfere depuis la chaine)');
      const rest = c.args.filter((a) => a !== emoji);
      const idArg = rest.find((a) => /^\d{1,9}$/.test(a));
      const { ref, jid, meta } = await target(c, rest.filter((a) => a !== idArg));
      let serverId = idArg || ref?.serverId;
      if (!serverId) { const p = await fetchPosts(c.sock, jid, 1); serverId = p[0]?.serverId; }
      if (!serverId) return c.reply('❌ Publication introuvable. Donnez son id (.channelpreview).');
      await c.sock.newsletterReactMessage(jid, String(serverId), emoji);
      return c.reply(`✅ Reaction ${emoji} envoyee a la publication #${serverId} de *${meta.name}*.`);
    }
  },
  {
    name: 'channelpost', aliases: ['cpost'], access: 'owner', desc: 'Publie dans une chaine administree', usage: '.channelpost <jid@newsletter> <texte> (ou media/texte cite)', async run(c) {
      const j = findJidInText(c.args[0] || ''); const jid = j && isNewsletter(j) ? j : isNewsletter(c.chat) ? c.chat : config.channelJid || null;
      if (!jid) return c.reply('Usage : .channelpost [120363xxxxxxxxxxxx@newsletter] Votre texte (sans JID : CHANNEL_JID de config.js ; repondez a une image/video pour publier un media)');
      const meta = await metadata(c.sock, { jid });
      if (!['OWNER', 'ADMIN'].includes(meta.role)) return c.reply(`❌ Ce compte n'est pas admin de *${meta.name}* (role : ${meta.role || 'abonne'}). Publication impossible.`);
      const text = (j && c.args[0] === j ? c.text.slice(j.length) : c.text).trim();
      const media = findMedia(c.m, ['image', 'video', 'audio']);
      let content;
      if (media) { const buf = await downloadBuffer(c.sock, media, c.logger); content = { [media.info.kind]: buf, mimetype: media.info.mime, ...(media.info.kind !== 'audio' ? { caption: text } : {}), ...(media.info.kind === 'audio' ? { ptt: true } : {}) }; }
      else { const q = c.quoted ? getText(c.quoted.message) : ''; const t = text || q; if (!t) return c.reply('❌ Rien a publier : ajoutez un texte ou un media.'); content = { text: t }; }
      await c.sock.sendMessage(jid, content);
      return c.reply(`✅ Publie dans *${meta.name}*.`);
    }
  },
  {
    name: 'channeldelete', aliases: ['cdelete'], access: 'owner', desc: 'SUPPRIME DEFINITIVEMENT une chaine dont le compte est proprietaire', usage: '.channeldelete <jid> CONFIRM', async run(c) {
      const j = findJidInText(c.args[0] || ''); if (!j || !isNewsletter(j)) return c.reply('Usage : .channeldelete 120363xxxxxxxxxxxx@newsletter CONFIRM');
      const meta = await metadata(c.sock, { jid: j });
      if (meta.role !== 'OWNER') return c.reply(`❌ Seul le proprietaire de la chaine peut la supprimer (role du compte : ${meta.role || 'abonne'}).`);
      if (c.args[1] !== 'CONFIRM') return c.reply(frame('⚠️ SUPPRESSION', [`📢 ${meta.name}`, `👥 ${meta.subscribers} abonnes`, 'Cette action est DEFINITIVE.', `Confirmez : ${c.prefix}channeldelete ${j} CONFIRM`]));
      await c.sock.newsletterDelete(j); delete db.channels.data.known[j]; db.channels.save();
      return c.reply(`🗑️ Chaine *${meta.name}* supprimee.`);
    }
  }
];
