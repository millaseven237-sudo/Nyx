import { jidNormalizedUser } from '@whiskeysockets/baileys';
import { db, S } from '../../lib/database.js';
import { frame, bar } from '../../lib/ui.js';
import { findMedia, downloadBuffer, getText, formatDuration, fmtDate } from '../../lib/utils.js';
import { extractTargets } from '../../handler/jidHandler.js';
import { numberOf, isGroup, toUserJid } from '../../lib/jidManager.js';
import * as bm from '../../lib/broadcastManager.js';

const pending = new Map();   // sender -> { name, targets, content, exp }

async function buildContent(c, text) {
  const media = findMedia(c.m, ['image', 'video', 'audio', 'document']);
  if (media) {
    const i = media.info; const buffer = await downloadBuffer(c.sock, media, c.logger);
    return { kind: i.kind, buffer, mimetype: i.mime, fileName: i.raw?.fileName, text, gif: !!i.raw?.gifPlayback, ptt: !!i.raw?.ptt };
  }
  const t = text || (c.quoted ? getText(c.quoted.message) : '');
  if (!t.trim()) throw new Error('Message vide : ecrivez un texte ou repondez a un media/texte.');
  return { kind: 'text', text: t.trim() };
}

async function prepare(c, name, targets, text, extra = {}) {
  const content = { ...(await buildContent(c, text)), ...extra };
  const cfg = S().broadcast; const n = new Set(targets).size;
  if (!n) throw new Error('Aucune cible disponible pour cette diffusion.');
  const eta = n * (cfg.minDelayMs + cfg.jitterMs / 2) + Math.floor(n / cfg.pauseEveryN) * cfg.pauseMs;
  pending.set(c.sender, { name, targets, content, exp: Date.now() + 120000 });
  return c.reply(frame('BROADCAST • CONFIRMATION', [`📡 Type : ${name}`, `🎯 Destinataires : ${n}`, `📦 Contenu : ${content.kind}${content.text ? ` — « ${content.text.slice(0, 80)}${content.text.length > 80 ? '…' : ''} »` : ''}`, `⏱️ Duree estimee : ~${formatDuration(eta)}`, `🛡️ Delai : ${cfg.minDelayMs / 1000}-${(cfg.minDelayMs + cfg.jitterMs) / 1000}s entre envois • quota restant : ${cfg.dailyCap - bm.stats().today}`, '', `✅ ${c.prefix}bcgo pour lancer (2 min)`, `❌ ${c.prefix}bccancel pour annuler`]));
}

const cmd = (name, desc, usage, targetsFn, label, extra, aliases = []) => ({
  name, aliases, access: 'owner', desc, usage,
  async run(c) {
    const targets = await targetsFn(c);
    return prepare(c, label, targets, c.text, extra?.(c) || {});
  }
});

const statusAudience = (c) => [...new Set([jidNormalizedUser(c.sock.user.id), ...bm.privateTargets()])];

export default [
  {
    name: 'broadcast', aliases: ['bc'], access: 'owner', desc: 'Diffuse un message vers une liste de diffusion', usage: '.broadcast <liste> | <message>  (media : repondre a un media)', async run(c) {
      const [listName, ...rest] = c.text.split('|'); const text = rest.join('|').trim(); const name = listName.trim().toLowerCase();
      const l = bm.lists()[name];
      if (!name) return c.reply(frame('BROADCAST', [`Usage : ${c.prefix}broadcast <liste> | <message>`, `Listes : ${Object.keys(bm.lists()).join(', ') || '(aucune)'}`, '', `${c.prefix}bcgroup  ${c.prefix}bcprivate  ${c.prefix}bcchannel  ${c.prefix}bcstatus  ${c.prefix}bcall`, `${c.prefix}broadcastlist  ${c.prefix}broadcaststats  ${c.prefix}broadcaststop`]));
      if (!l) return c.reply(`❌ Liste "${name}" introuvable. Creez-la : ${c.prefix}broadcastlist create ${name}`);
      return prepare(c, `liste « ${name} »`, l.jids, text);
    }
  },
  cmd('bcgroup', 'Diffuse dans tous les groupes (hors exclus)', '.bcgroup <message>', (c) => bm.groupTargets(c.sock), 'groupes'),
  cmd('bcprivate', 'Diffuse aux utilisateurs ayant deja ecrit en prive au bot', '.bcprivate <message>', async () => bm.privateTargets(), 'prive'),
  cmd('bcchannel', 'Publie dans les chaines administrees par le compte', '.bcchannel <message>', (c) => bm.channelTargets(c.sock), 'chaines'),
  cmd('bcstatus', 'Publie dans votre Statut WhatsApp (audience : contacts connus du bot)', '.bcstatus <texte> (ou media)', async () => ['status@broadcast'], 'statut WhatsApp', (c) => ({ statusJidList: statusAudience(c) })),
  cmd('bcall', 'Diffuse dans les groupes ET aux utilisateurs prives', '.bcall <message>', async (c) => [...(await bm.groupTargets(c.sock)), ...bm.privateTargets()], 'groupes + prive'),
  {
    name: 'bcgo', access: 'owner', desc: 'Lance la diffusion preparee', async run(c) {
      const p = pending.get(c.sender); if (!p || p.exp < Date.now()) { pending.delete(c.sender); return c.reply('❌ Aucune diffusion en attente (ou delai de 2 min depasse).'); }
      pending.delete(c.sender);
      const job = bm.createJob({ sock: c.sock, name: p.name, targets: p.targets, content: p.content, by: c.sender, reply: (t) => c.sock.sendMessage(c.chat, { text: t }) });
      return c.reply(frame('BROADCAST • LANCE', [`🆔 ${job.id}`, `🎯 ${job.total} destinataire(s)`, `${c.prefix}broadcaststats pour suivre`, `${c.prefix}broadcaststop pause|resume|stop ${job.id}`]));
    }
  },
  { name: 'bccancel', access: 'owner', desc: 'Annule la diffusion en attente', async run(c) { return c.reply(pending.delete(c.sender) ? '✅ Diffusion annulee.' : 'Aucune diffusion en attente.'); } },
  {
    name: 'broadcastlist', aliases: ['bclist'], access: 'owner', desc: 'Gere les listes de diffusion', usage: '.broadcastlist create|add|remove|del|show|exclude|optout ...', async run(c) {
      const sub = c.args[0]?.toLowerCase(); const lists = bm.lists(); const name = c.args[1]?.toLowerCase();
      if (!sub || sub === 'list') return c.reply(frame('BROADCAST LISTS', [...Object.entries(lists).map(([k, v]) => `📋 ${k} — ${v.jids.length} destinataire(s)`), !Object.keys(lists).length ? 'Aucune liste.' : null, '', `${c.prefix}broadcastlist create <nom>`, `${c.prefix}broadcastlist add <nom> <@user|numero|jid>  (ou "here" = ce chat)`, `${c.prefix}broadcastlist remove <nom> <...>`, `${c.prefix}broadcastlist show|del <nom>`, `${c.prefix}broadcastlist exclude   (groupe courant exclu des diffusions)`, `${c.prefix}broadcastlist optout <@user>`]));
      if (sub === 'exclude') { if (!c.isGroup) return c.reply('A utiliser dans un groupe.'); const g = (db.groups.data.list[c.chat] ||= {}); g.bcExclude = !g.bcExclude; db.groups.save(); return c.reply(g.bcExclude ? '🚫 Ce groupe est exclu des diffusions.' : '✅ Ce groupe peut recevoir des diffusions.'); }
      if (sub === 'optout') { const t = extractTargets(c.m, c.args.slice(1)); t.forEach((j) => { const u = (db.users.data.list[j] ||= { first: Date.now(), count: 0 }); u.bcOptOut = !u.bcOptOut; }); db.users.save(); return c.reply(`✅ ${t.length} utilisateur(s) bascule(s) (opt-out des diffusions).`); }
      if (!name) return c.reply('Precisez le nom de la liste.');
      if (sub === 'create') { if (lists[name]) return c.reply('❌ Cette liste existe deja.'); if (Object.keys(lists).length >= 20) return c.reply('❌ 20 listes maximum.'); lists[name] = { jids: [], created: Date.now() }; db.broadcast.save(); return c.reply(`✅ Liste « ${name} » creee.`); }
      const l = lists[name]; if (!l) return c.reply('❌ Liste introuvable.');
      if (sub === 'del') { delete lists[name]; db.broadcast.save(); return c.reply(`🗑️ Liste « ${name} » supprimee.`); }
      if (sub === 'show') return c.reply(frame(`LISTE ${name} (${l.jids.length})`, l.jids.slice(0, 60).map((j) => `▫️ ${j}`)));
      if (sub === 'add' || sub === 'remove') {
        const raw = c.args.slice(2); const jids = [];
        if (raw[0] === 'here') jids.push(c.chat); else {
          for (const a of raw) if (/@(g\.us|s\.whatsapp\.net|newsletter)$/.test(a)) jids.push(a);
          jids.push(...extractTargets(c.m, raw.filter((a) => !a.includes('@g.us') && !a.includes('@newsletter') && !a.includes('@s.whatsapp.net'))));
        }
        if (!jids.length) return c.reply('Precisez au moins un destinataire.');
        if (sub === 'add') { for (const j of jids) if (!l.jids.includes(j)) l.jids.push(j); } else l.jids = l.jids.filter((j) => !jids.includes(j));
        db.broadcast.save(); return c.reply(`✅ Liste « ${name} » : ${l.jids.length} destinataire(s).`);
      }
      return c.reply('❌ Sous-commande inconnue.');
    }
  },
  {
    name: 'broadcaststop', aliases: ['bcstop'], access: 'owner', desc: 'Pause / reprise / arret d\'une diffusion', usage: '.broadcaststop [pause|resume|stop] [id]', async run(c) {
      let action = c.args[0]?.toLowerCase(); let id = c.args[1];
      if (!['pause', 'resume', 'stop'].includes(action)) { id = c.args[0]; action = 'stop'; }
      const n = bm.control(id, action);
      return c.reply(`✅ ${action} applique a ${n} diffusion(s).`);
    }
  },
  {
    name: 'broadcaststats', aliases: ['bcstats'], access: 'owner', desc: 'Etat et statistiques des diffusions', async run(c) {
      const s = bm.stats(); const act = bm.activeJobs();
      const fmt = (j) => `🆔 ${j.id} • ${j.name} • ${j.state}${j.paused ? ' ⏸️' : ''}\n   ${bar(j.sent + j.failed, j.total, 10)}  ✅${j.sent} ❌${j.failed} / ${j.total}`;
      const hist = bm.history().filter((j) => !act.some((a) => a.id === j.id));
      return c.reply(frame('BROADCAST STATS', [`📅 Aujourd'hui : ${s.today}/${s.cap} envois`, `▶️ Actives : ${act.length}`, ...act.map(fmt), '', '🕘 Historique', ...(hist.length ? hist.flatMap((j) => [fmt(j), `   ${fmtDate(j.created)}`, ...(j.errors?.length ? [`   ⚠️ ${j.errors.at(-1)}`] : [])]) : ['(vide)'])]));
    }
  }
];
