import { frame } from '../../lib/ui.js';
import { db } from '../../lib/database.js';
import { extractTargets, sameUser, participantIds } from '../../handler/jidHandler.js';
import { numberOf, groupInviteUrl } from '../../lib/jidManager.js';
import { getGroupMeta, invalidateMeta, groupSettings } from '../../lib/groupUtils.js';
import { sleep, getText } from '../../lib/utils.js';

const A = { access: 'admin', group: true };
const AB = { access: 'admin', group: true, botAdmin: true };
const pid = (p) => p.phoneNumber || p.id;      // JID utilisable pour mentionner / agir
const isAdm = (p) => !!p.admin;
const bodyOf = (c) => c.text || (c.quoted ? getText(c.quoted.message) : '');

async function update(c, action, label) {
  const t = extractTargets(c.m, c.args); if (!t.length) throw new Error(`Mentionnez ou citez un membre. Usage : ${c.prefix}${c.command} @user`);
  const meta = await getGroupMeta(c.sock, c.chat, true);
  // on cible l'identifiant tel que le groupe le connait (id/lid/pn)
  const ids = t.map((j) => meta.participants.find((p) => sameUser(participantIds(p), j))?.id || j);
  if (action === 'remove') { const protectedIds = ids.filter((j) => meta.participants.some((p) => p.id === j && p.admin === 'superadmin')); if (protectedIds.length) throw new Error('Impossible de retirer le createur du groupe.'); }
  const res = await c.sock.groupParticipantsUpdate(c.chat, ids, action); invalidateMeta(c.chat);
  const ok = res.filter((r) => String(r.status) === '200').length;
  return c.reply(`${ok ? '✅' : '❌'} ${label} : ${ok}/${ids.length} reussi(s).${ok < ids.length ? `\nCodes : ${res.map((r) => r.status).join(', ')}` : ''}`, { mentions: t });
}
const toggle = (name, key, label, desc) => ({
  name, ...A, desc, usage: `.${name} on|off`, async run(c) {
    const v = c.args[0]?.toLowerCase(); const g = groupSettings(c.chat);
    if (!['on', 'off'].includes(v)) return c.reply(`${label} : ${g[key] ? 'ON' : 'OFF'}\nUsage : ${c.prefix}${name} on|off`);
    g[key] = v === 'on'; db.groups.save(); return c.reply(`✅ ${label} ${v === 'on' ? 'active' : 'desactive'}.`);
  }
});

export default [
  { name: 'kick', aliases: ['remove', 'ban'], ...AB, desc: 'Retire un membre', usage: '.kick @user', async run(c) { return update(c, 'remove', 'Retrait'); } },
  {
    name: 'add', ...AB, desc: 'Ajoute un numero au groupe', usage: '.add 237xxxxxxxxx', async run(c) {
      const nums = c.args.map((a) => a.replace(/\D/g, '')).filter((n) => n.length >= 7); if (!nums.length) return c.reply('Usage : .add 237xxxxxxxxx');
      const res = await c.sock.groupParticipantsUpdate(c.chat, nums.map((n) => `${n}@s.whatsapp.net`), 'add'); invalidateMeta(c.chat);
      const txt = res.map((r) => `${String(r.status) === '200' ? '✅' : String(r.status) === '403' ? '📩 invitation requise (confidentialite)' : String(r.status) === '408' ? '⏳ a quitte recemment' : `❌ ${r.status}`} +${numberOf(r.jid || '')}`);
      for (const r of res) if (String(r.status) === '403') { try { const code = await c.sock.groupInviteCode(c.chat); await c.sock.sendMessage(r.jid, { text: `Vous etes invite a rejoindre le groupe *${c.meta?.subject}* : ${groupInviteUrl(code)}` }); txt.push(`📨 lien envoye a +${numberOf(r.jid)}`); } catch {} }
      return c.reply(frame('ADD', txt));
    }
  },
  { name: 'promote', ...AB, desc: 'Nomme admin', usage: '.promote @user', async run(c) { return update(c, 'promote', 'Promotion'); } },
  { name: 'demote', ...AB, desc: 'Retire le statut admin', usage: '.demote @user', async run(c) { return update(c, 'demote', 'Retrogradation'); } },
  {
    name: 'tagall', aliases: ['everyone'], ...A, desc: 'Mentionne tous les membres', usage: '.tagall [message]', async run(c) {
      const meta = await getGroupMeta(c.sock, c.chat); const ids = meta.participants.map(pid);
      return c.send({ text: frame('TAGALL', [`📢 ${c.text || 'Attention svp !'}`, '', ...ids.map((j) => `▫️ @${numberOf(j)}`)]), mentions: ids });
    }
  },
  {
    name: 'hidetag', aliases: ['h-tag', 'notify'], ...A, desc: 'Message avec mention invisible de tous', usage: '.hidetag <texte> (ou citer un message)', async run(c) {
      const t = bodyOf(c); if (!t) return c.reply('Usage : .hidetag <texte>');
      const meta = await getGroupMeta(c.sock, c.chat); return c.sock.sendMessage(c.chat, { text: t, mentions: meta.participants.map(pid) });
    }
  },
  {
    name: 'tagadmins', aliases: ['admins'], ...A, desc: 'Mentionne les admins', async run(c) {
      const meta = await getGroupMeta(c.sock, c.chat); const ids = meta.participants.filter(isAdm).map(pid);
      return c.send({ text: frame('ADMINS', [`🛡️ ${c.text || 'Appel aux admins'}`, '', ...ids.map((j) => `👑 @${numberOf(j)}`)]), mentions: ids });
    }
  },
  {
    name: 'tagmembers', aliases: ['members'], ...A, desc: 'Mentionne les membres (hors admins)', async run(c) {
      const meta = await getGroupMeta(c.sock, c.chat); const ids = meta.participants.filter((p) => !isAdm(p)).map(pid);
      return c.send({ text: frame('MEMBERS', [`👥 ${c.text || 'Appel aux membres'}`, '', ...ids.map((j) => `▫️ @${numberOf(j)}`)]), mentions: ids });
    }
  },
  {
    name: 'mute', ...AB, desc: 'Reduit au silence un membre (ses messages sont supprimes)', usage: '.mute @user', async run(c) {
      const t = extractTargets(c.m, c.args); if (!t.length) return c.reply('Usage : .mute @user');
      const l = (db.muted.data.list[c.chat] ||= []); t.forEach((j) => { if (!l.includes(j)) l.push(j); }); db.muted.save();
      return c.reply(`🔇 ${t.length} membre(s) reduit(s) au silence. ${c.prefix}unmute pour annuler.`, { mentions: t });
    }
  },
  {
    name: 'unmute', ...A, desc: 'Retire le silence d\'un membre', usage: '.unmute @user', async run(c) {
      const t = extractTargets(c.m, c.args); const l = db.muted.data.list[c.chat] || [];
      db.muted.data.list[c.chat] = l.filter((j) => !t.some((x) => sameUser(j, x))); db.muted.save(); return c.reply('🔊 Membre(s) de nouveau autorise(s).', { mentions: t });
    }
  },
  { name: 'lock', ...AB, desc: 'Seuls les admins modifient les infos du groupe', async run(c) { await c.sock.groupSettingUpdate(c.chat, 'locked'); return c.reply('🔒 Infos du groupe verrouillees (admins seulement).'); } },
  { name: 'unlock', ...AB, desc: 'Tous peuvent modifier les infos du groupe', async run(c) { await c.sock.groupSettingUpdate(c.chat, 'unlocked'); return c.reply('🔓 Infos du groupe deverrouillees.'); } },
  { name: 'groupclose', aliases: ['close'], ...AB, desc: 'Seuls les admins peuvent ecrire', async run(c) { await c.sock.groupSettingUpdate(c.chat, 'announcement'); return c.reply('🔒 Groupe ferme : seuls les admins peuvent ecrire.'); } },
  { name: 'groupopen', aliases: ['open'], ...AB, desc: 'Tout le monde peut ecrire', async run(c) { await c.sock.groupSettingUpdate(c.chat, 'not_announcement'); return c.reply('🔓 Groupe ouvert : tout le monde peut ecrire.'); } },
  toggle('welcome', 'welcome', 'Message de bienvenue', 'Active/desactive le message de bienvenue'),
  toggle('goodbye', 'goodbye', 'Message d\'au revoir', 'Active/desactive le message d\'au revoir'),
  {
    name: 'setwelcome', ...A, desc: 'Texte de bienvenue (@user @group @count @desc)', usage: '.setwelcome <texte>|reset', async run(c) { const g = groupSettings(c.chat); g.welcomeText = c.text === 'reset' ? '' : c.text.slice(0, 500); db.groups.save(); return c.reply('✅ Texte de bienvenue mis a jour.'); }
  },
  {
    name: 'setgoodbye', ...A, desc: 'Texte d\'au revoir (@user @group @count)', usage: '.setgoodbye <texte>|reset', async run(c) { const g = groupSettings(c.chat); g.goodbyeText = c.text === 'reset' ? '' : c.text.slice(0, 500); db.groups.save(); return c.reply('✅ Texte d\'au revoir mis a jour.'); }
  },
  {
    name: 'antilink', ...A, desc: 'Supprime les liens', usage: '.antilink on|off|kick|delete|all|wa', async run(c) {
      const g = groupSettings(c.chat); const v = c.args[0]?.toLowerCase();
      if (v === 'on' || v === 'off') g.antilink = v === 'on'; else if (v === 'kick' || v === 'delete') { g.antilinkAction = v; g.antilink = true; } else if (v === 'all') g.antilinkAll = true; else if (v === 'wa') g.antilinkAll = false;
      else return c.reply(frame('ANTILINK', [`Etat : ${g.antilink ? 'ON' : 'OFF'}`, `Action : ${g.antilinkAction}`, `Portee : ${g.antilinkAll ? 'tous les liens' : 'liens de groupes WhatsApp'}`, `${c.prefix}antilink on|off|kick|delete|all|wa`, !0 ? '🤖 Necessite que le bot soit admin.' : '']));
      db.groups.save(); return c.reply(`✅ Antilink : ${g.antilink ? 'ON' : 'OFF'} • action ${g.antilinkAction} • ${g.antilinkAll ? 'tous liens' : 'liens WhatsApp'}${c.isBotAdmin ? '' : '\n⚠️ Je ne suis pas admin : je ne pourrai pas supprimer.'}`);
    }
  },
  toggle('antispam', 'antispam', 'Anti-spam', 'Limite le flood de messages (bot admin requis)'),
  toggle('antibot', 'antibot', 'Anti-bot', 'Retire les bots detectes (heuristique, bot admin requis)'),
  {
    name: 'grouptitle', aliases: ['setname'], ...AB, desc: 'Change le nom du groupe', usage: '.grouptitle <nom>', async run(c) { if (!c.text) return c.reply('Usage : .grouptitle <nouveau nom>'); await c.sock.groupUpdateSubject(c.chat, c.text.slice(0, 100)); invalidateMeta(c.chat); return c.reply('✅ Nom du groupe modifie.'); }
  },
  {
    name: 'groupdesc', aliases: ['setdesc'], ...AB, desc: 'Change la description', usage: '.groupdesc <texte>', async run(c) { if (!c.text) return c.reply('Usage : .groupdesc <description>'); await c.sock.groupUpdateDescription(c.chat, c.text.slice(0, 2000)); invalidateMeta(c.chat); return c.reply('✅ Description modifiee.'); }
  },
  {
    name: 'poll', ...A, desc: 'Cree un sondage', usage: '.poll Question | option1 | option2 ...', async run(c) {
      const [q, ...opts] = c.text.split('|').map((x) => x.trim()).filter(Boolean);
      if (!q || opts.length < 2 || opts.length > 12) return c.reply('Usage : .poll Question | option1 | option2 (2 a 12 options)');
      return c.sock.sendMessage(c.chat, { poll: { name: q.slice(0, 200), values: opts.map((o) => o.slice(0, 100)), selectableCount: 1 } });
    }
  },
  {
    name: 'invite', ...AB, desc: 'Envoie le lien du groupe a un numero', usage: '.invite 237xxxxxxxxx', async run(c) {
      const n = c.args[0]?.replace(/\D/g, ''); if (!n || n.length < 7) return c.reply('Usage : .invite 237xxxxxxxxx');
      const [r] = await c.sock.onWhatsApp(n) || []; if (!r?.exists) return c.reply('❌ Ce numero n\'est pas sur WhatsApp.');
      const code = await c.sock.groupInviteCode(c.chat);
      await c.sock.sendMessage(r.jid, { text: `📩 Invitation au groupe *${c.meta?.subject}*\n${groupInviteUrl(code)}` }); return c.reply(`✅ Invitation envoyee a +${n}.`);
    }
  },
  {
    name: 'revoke', aliases: ['resetlink'], ...AB, desc: 'Revoque le lien d\'invitation', async run(c) { const code = await c.sock.groupRevokeInvite(c.chat); return c.reply(frame('REVOKE', ['♻️ Ancien lien invalide', `🔗 ${groupInviteUrl(code)}`])); }
  }
];
