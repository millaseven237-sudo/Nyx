import QRCode from 'qrcode';
import jsQR from 'jsqr';
import { config } from '../../config.js';
import { S } from '../../lib/database.js';
import { frame } from '../../lib/ui.js';
import { findMedia, downloadBuffer, ffmpegBuffer, ffmpeg, formatBytes, getText, fetchJson, tmpPath, rmSafe } from '../../lib/utils.js';
import { gemini, aiReady } from '../../lib/ai.js';
import fs from 'node:fs';

const need = (c, kinds, hint) => { const t = findMedia(c.m, kinds); if (!t) throw new Error(hint); return t; };
const API = (n) => `⚠️ ${n} necessite une cle API : ajoutez-la dans config.js .`;
const evenScale = 'scale=trunc(iw/2)*2:trunc(ih/2)*2';

export default [
  {
    name: 'tomp3', aliases: ['mp3'], desc: 'Video / audio -> MP3', async run(c) {
      const t = need(c, ['video', 'audio'], 'Repondez a une video ou un audio.'); const buf = await downloadBuffer(c.sock, t, c.logger);
      const out = await ffmpegBuffer(buf, t.info.kind === 'video' ? '.mp4' : '.ogg', '.mp3', (i, o) => ['-i', i, '-vn', '-c:a', 'libmp3lame', '-q:a', '4', o], { timeout: 120000 });
      return c.send({ audio: out, mimetype: 'audio/mpeg' });
    }
  },
  {
    name: 'toaudio', aliases: ['tovn'], desc: 'Video -> note vocale / audio (opus)', async run(c) {
      const t = need(c, ['video', 'audio'], 'Repondez a une video ou un audio.'); const buf = await downloadBuffer(c.sock, t, c.logger);
      const out = await ffmpegBuffer(buf, t.info.kind === 'video' ? '.mp4' : '.mp3', '.ogg', (i, o) => ['-i', i, '-vn', '-c:a', 'libopus', '-b:a', '64k', '-ar', '48000', '-ac', '1', o], { timeout: 120000 });
      return c.send({ audio: out, mimetype: 'audio/ogg; codecs=opus', ptt: true });
    }
  },
  {
    name: 'compress', desc: 'Compresse une image ou une video', usage: '.compress [1-10 force]', async run(c) {
      const t = need(c, ['image', 'video'], 'Repondez a une image ou une video.'); const lvl = Math.min(10, Math.max(1, Number(c.args[0]) || 5)); const buf = await downloadBuffer(c.sock, t, c.logger);
      if (t.info.kind === 'image') { const out = await ffmpegBuffer(buf, '.png', '.jpg', (i, o) => ['-i', i, '-vf', 'scale=min(1280\\,iw):-2', '-q:v', String(2 + lvl * 2.5), o]); return c.send({ image: out, caption: `🗜️ ${formatBytes(buf.length)} → ${formatBytes(out.length)}` }); }
      if (t.info.seconds > 120) throw new Error('Video trop longue (2 min max).');
      const out = await ffmpegBuffer(buf, '.mp4', '.mp4', (i, o) => ['-i', i, '-vf', `scale='min(854,iw)':-2`, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', String(24 + lvl), '-c:a', 'aac', '-b:a', '64k', '-movflags', '+faststart', o], { timeout: 180000 });
      return c.send({ video: out, caption: `🗜️ ${formatBytes(buf.length)} → ${formatBytes(out.length)}` });
    }
  },
  {
    name: 'resize', desc: 'Redimensionne une image', usage: '.resize <largeur> | <LxH>', async run(c) {
      const t = need(c, ['image'], 'Repondez a une image.'); const m = c.args[0]?.match(/^(\d{2,4})(?:x(\d{2,4}))?$/i); if (!m) return c.reply('Usage : .resize 800  ou  .resize 800x600');
      const w = Math.min(4000, Number(m[1])), h = m[2] ? Math.min(4000, Number(m[2])) : -1;
      const out = await ffmpegBuffer(await downloadBuffer(c.sock, t, c.logger), '.png', '.png', (i, o) => ['-i', i, '-vf', `scale=${w}:${h}`, o]);
      return c.send({ image: out, caption: `📐 ${w}x${h === -1 ? 'auto' : h}` });
    }
  },
  {
    name: 'crop', desc: 'Recadre une image au centre', usage: '.crop <1:1|16:9|4:5> ou .crop <LxH>', async run(c) {
      const t = need(c, ['image'], 'Repondez a une image.'); const a = c.args[0] || '1:1'; let vf;
      const r = a.match(/^(\d+):(\d+)$/), d = a.match(/^(\d{2,4})x(\d{2,4})$/i);
      if (r) vf = `crop='if(gte(iw/ih,${r[1]}/${r[2]}),ih*${r[1]}/${r[2]},iw)':'if(gte(iw/ih,${r[1]}/${r[2]}),ih,iw*${r[2]}/${r[1]})'`;
      else if (d) vf = `crop=min(iw\\,${d[1]}):min(ih\\,${d[2]})`; else return c.reply('Usage : .crop 1:1  |  .crop 16:9  |  .crop 500x500');
      return c.send({ image: await ffmpegBuffer(await downloadBuffer(c.sock, t, c.logger), '.png', '.png', (i, o) => ['-i', i, '-vf', vf, o]), caption: '✂️ Recadre' });
    }
  },
  {
    name: 'blur', desc: 'Floute une image ou une video', usage: '.blur [1-30]', async run(c) {
      const t = need(c, ['image', 'video'], 'Repondez a une image ou une video.'); const s = Math.min(30, Math.max(1, Number(c.args[0]) || 8)); const buf = await downloadBuffer(c.sock, t, c.logger);
      if (t.info.kind === 'image') return c.send({ image: await ffmpegBuffer(buf, '.png', '.png', (i, o) => ['-i', i, '-vf', `gblur=sigma=${s}`, o]), caption: '🌫️ Floute' });
      if (t.info.seconds > 60) throw new Error('Video trop longue (60 s max).');
      return c.send({ video: await ffmpegBuffer(buf, '.mp4', '.mp4', (i, o) => ['-i', i, '-vf', `gblur=sigma=${s},${evenScale}`, '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '27', '-c:a', 'copy', '-movflags', '+faststart', o], { timeout: 180000 }), caption: '🌫️ Floute' });
    }
  },
  {
    name: 'qr', aliases: ['qrcode'], desc: 'Genere un QR code', usage: '.qr <texte ou lien>', async run(c) {
      const text = c.text || (c.quoted ? getText(c.quoted.message) : ''); if (!text) return c.reply('Usage : .qr <texte ou lien>'); if (text.length > 1000) throw new Error('Texte trop long (1000 car. max).');
      const png = await QRCode.toBuffer(text, { width: 640, margin: 2, color: { dark: '#2a0a52', light: '#ffffff' } });
      return c.send({ image: png, caption: '🟪 QR code genere' });
    }
  },
  {
    name: 'readqr', aliases: ['scanqr'], desc: 'Lit un QR code depuis une image', async run(c) {
      const t = need(c, ['image', 'sticker'], 'Repondez a une image contenant un QR code.'); const W = 900;
      const raw = await ffmpegBuffer(await downloadBuffer(c.sock, t, c.logger), '.img', '.rgba', (i, o) => ['-i', i, '-vf', `scale=${W}:-2`, '-f', 'rawvideo', '-pix_fmt', 'rgba', o]);
      const H = Math.floor(raw.length / (W * 4));
      const res = jsQR(new Uint8ClampedArray(raw.buffer, raw.byteOffset, W * H * 4), W, H, { inversionAttempts: 'attemptBoth' });
      return c.reply(res ? frame('QR LU', [res.data]) : '❌ Aucun QR code lisible dans cette image.');
    }
  },
  {
    name: 'tts', desc: 'Texte -> voix (service Google Translate TTS, non officiel)', usage: '.tts [langue] <texte>', async run(c) {
      let [lang, ...r] = c.args; let text = r.join(' ');
      if (!/^[a-z]{2}(-[A-Za-z]{2,4})?$/.test(lang || '') ) { text = c.text; lang = 'fr'; }
      text = text || (c.quoted ? getText(c.quoted.message) : ''); if (!text) return c.reply('Usage : .tts fr Bonjour tout le monde');
      if (text.length > 600) throw new Error('Texte trop long (600 car. max).');
      const parts = text.match(/[\s\S]{1,180}(?:\s|$)/g) || [text]; const bufs = [];
      for (const p of parts) {
        const r2 = await fetch(`https://translate.google.com/translate_tts?ie=UTF-8&client=tw-ob&tl=${encodeURIComponent(lang)}&q=${encodeURIComponent(p.trim())}`, { headers: { 'User-Agent': 'Mozilla/5.0' } });
        if (!r2.ok) throw new Error(`Service TTS indisponible (HTTP ${r2.status}).`); bufs.push(Buffer.from(await r2.arrayBuffer()));
      }
      return c.send({ audio: Buffer.concat(bufs), mimetype: 'audio/mpeg', ptt: true });
    }
  },
  {
    name: 'transcribe', aliases: ['stt'], desc: 'Audio -> texte (Gemini requis)', async run(c) {
      if (!aiReady()) return c.reply(API('.transcribe (GEMINI_API_KEY)'));
      const t = need(c, ['audio', 'video'], 'Repondez a une note vocale ou un audio.'); if (t.info.seconds > 600) throw new Error('Audio trop long (10 min max).');
      let buf = await downloadBuffer(c.sock, t, c.logger); let mime = t.info.mime.split(';')[0] || 'audio/ogg';
      if (buf.length > 14 * 1024 * 1024) throw new Error('Fichier trop lourd pour l\'analyse (14 Mo max).');
      const txt = await gemini({ prompt: 'Transcris fidelement cet enregistrement dans sa langue d\'origine. Reponds uniquement par la transcription.', media: { buffer: buf, mime } });
      return c.reply(frame('TRANSCRIPTION', [txt.slice(0, 3000)]));
    }
  },
  {
    name: 'translate', aliases: ['tr'], desc: 'Traduit un texte (MyMemory, gratuit)', usage: '.translate <langue> <texte> (ou citer un message)', async run(c) {
      let lang = c.args[0]; let text = c.args.slice(1).join(' ');
      if (!/^[a-z]{2}(-[A-Za-z]{2})?$/.test(lang || '')) { text = c.text; lang = 'fr'; }
      text = text || (c.quoted ? getText(c.quoted.message) : ''); if (!text) return c.reply('Usage : .translate en Bonjour  (langue = code : fr, en, es, ar…)');
      if (text.length > 480) throw new Error('Texte trop long (480 car. max).');
      const j = await fetchJson(`https://api.mymemory.translated.net/get?q=${encodeURIComponent(text)}&langpair=${encodeURIComponent('autodetect|' + lang)}`);
      const out = j?.responseData?.translatedText; if (!out || j.responseStatus !== 200) throw new Error(j?.responseDetails || 'Traduction impossible.');
      return c.reply(frame(`TRADUCTION → ${lang}`, [out]));
    }
  },
  {
    name: 'caption', aliases: ['describe'], desc: 'Decrit une image (Gemini requis)', async run(c) {
      if (!aiReady()) return c.reply(API('.caption (GEMINI_API_KEY)'));
      const t = need(c, ['image'], 'Repondez a une image.');
      const txt = await gemini({ prompt: `Decris cette image en francais, en 2 a 3 phrases. ${c.text}`, media: { buffer: await downloadBuffer(c.sock, t, c.logger), mime: t.info.mime || 'image/jpeg' } });
      return c.reply(frame('CAPTION', [txt]));
    }
  },
  {
    name: 'removebg', aliases: ['rmbg'], desc: 'Supprime l\'arriere-plan (API remove.bg requise)', async run(c) {
      if (!config.removebgKey) return c.reply(API('.removebg (REMOVEBG_API_KEY)'));
      const t = need(c, ['image'], 'Repondez a une image.'); const buf = await downloadBuffer(c.sock, t, c.logger);
      const fd = new FormData(); fd.append('size', 'auto'); fd.append('image_file', new Blob([buf], { type: t.info.mime || 'image/jpeg' }), 'image.jpg');
      const r = await fetch('https://api.remove.bg/v1.0/removebg', { method: 'POST', headers: { 'X-Api-Key': config.removebgKey }, body: fd });
      if (!r.ok) throw new Error(`remove.bg : ${(await r.text()).slice(0, 160)}`);
      return c.send({ document: Buffer.from(await r.arrayBuffer()), mimetype: 'image/png', fileName: 'nyx_nobg.png', caption: '✂️ Arriere-plan supprime' });
    }
  }
];
