import { commands, findCommand } from '../../handler/commandHandler.js';
import { config } from '../../config.js';
import { db, S } from '../../lib/database.js';
import { frame, CATEGORIES } from '../../lib/ui.js';
import { extractTargets } from '../../handler/jidHandler.js';
import { numberOf } from '../../lib/jidManager.js';
import { isPrimaryOwner } from '../../handler/permissionHandler.js';
import { defaultSettings } from '../../settings.js';
import { fmtDate, formatDuration } from '../../lib/utils.js';

const flat = (o, p = '') => Object.entries(o).flatMap(([k, v]) => (v && typeof v === 'object' && !Array.isArray(v) ? flat(v, `${p}${k}.`) : [[`${p}${k}`, v]]));
const getPath = (o, k) => k.split('.').reduce((a, x) => a?.[x], o);
const setPath = (o, k, v) => { const ps = k.split('.'); const last = ps.pop(); const t = ps.reduce((a, x) => a[x], o); t[last] = v; };
const RANGES = { stickerPackLimit: [1, 60], maxMediaMB: [1, 100], maxVideoSeconds: [1, 30], 'broadcast.minDelayMs': [2000, 120000], 'broadcast.maxRecipientsPerJob': [1, 1000], 'broadcast.dailyCap': [1, 5000], commandCooldownMs: [0, 60000] };

export default [
  {
    name: 'addowner', access: 'owner', desc: 'Ajoute un owner secondaire', usage: '.addowner @user|numero', async run(c) {
      if (!isPrimaryOwner(c.senderIds) && !c.m.key.fromMe) return c.reply('❌ Seul l\'owner principal peut ajouter des owners.');
      const t = extractTargets(c.m, c.args); if (!t.length) return c.reply('Usage : .addowner @user ou .addowner 237xxxxxxxxx');
      const added = []; for (const j of t) { const n = db.lidmap.data.map[numberOf(j)] || numberOf(j); if (!db.owners.data.secondary.includes(n) && n !== config.ownerNumber) { db.owners.data.secondary.push(n); added.push(n); } }
      db.owners.save(); return c.reply(added.length ? `✅ Owner(s) ajoute(s) : ${added.map((n) => '+' + n).join(', ')}` : 'ℹ️ Deja owner.');
    }
  },
  {
    name: 'delowner', access: 'owner', desc: 'Retire un owner secondaire', usage: '.delowner @user|numero', async run(c) {
      if (!isPrimaryOwner(c.senderIds) && !c.m.key.fromMe) return c.reply('❌ Seul l\'owner principal peut retirer des owners.');
      const t = extractTargets(c.m, c.args).map((j) => db.lidmap.data.map[numberOf(j)] || numberOf(j));
      const before = db.owners.data.secondary.length; db.owners.data.secondary = db.owners.data.secondary.filter((n) => !t.includes(n)); db.owners.save();
      return c.reply(before > db.owners.data.secondary.length ? '✅ Owner retire.' : 'ℹ️ Aucun owner secondaire correspondant.');
    }
  },
  { name: 'owners', access: 'owner', desc: 'Liste des owners', async run(c) { return c.reply(frame('OWNERS', [`👑 Principal : +${config.ownerNumber || '(non defini)'}`, ...db.owners.data.secondary.map((n) => `🔹 Secondaire : +${n}`)])); } },
  {
    name: 'setperm', aliases: ['perm'], access: 'owner', desc: 'Niveau d\'acces d\'une commande', usage: '.setperm <cmd> <public|admin|owner|reset>', async run(c) {
      const cmd = findCommand(c.args[0]); const lvl = c.args[1]?.toLowerCase();
      if (!cmd || !['public', 'admin', 'owner', 'reset'].includes(lvl)) return c.reply('Usage : .setperm <commande> <public|admin|owner|reset>');
      const ov = (db.perms.data.commands[cmd.name] ||= {});
      if (lvl === 'reset') delete ov.level; else ov.level = lvl;
      db.perms.save(); return c.reply(`✅ ${c.prefix}${cmd.name} : acces ${lvl === 'reset' ? `par defaut (${cmd.access || 'public'})` : lvl}.`);
    }
  },
  {
    name: 'allow', access: 'owner', desc: 'Autorise (ou retire) un utilisateur sur une commande', usage: '.allow <cmd> @user', async run(c) {
      const cmd = findCommand(c.args[0]); const t = extractTargets(c.m, c.args.slice(1)); if (!cmd || !t.length) return c.reply('Usage : .allow <commande> @user (relancer pour retirer)');
      const ov = (db.perms.data.commands[cmd.name] ||= {}); ov.allow ||= [];
      const out = t.map((j) => { const i = ov.allow.indexOf(j); if (i >= 0) { ov.allow.splice(i, 1); return `➖ ${numberOf(j)}`; } ov.allow.push(j); return `➕ ${numberOf(j)}`; });
      db.perms.save(); return c.reply(frame('ALLOW', [`${c.prefix}${cmd.name}`, ...out]));
    }
  },
  {
    name: 'deny', access: 'owner', desc: 'Interdit (ou retire l\'interdiction) a un utilisateur', usage: '.deny <cmd> @user', async run(c) {
      const cmd = findCommand(c.args[0]); const t = extractTargets(c.m, c.args.slice(1)); if (!cmd || !t.length) return c.reply('Usage : .deny <commande> @user (relancer pour retirer)');
      const ov = (db.perms.data.commands[cmd.name] ||= {}); ov.deny ||= [];
      const out = t.map((j) => { const i = ov.deny.indexOf(j); if (i >= 0) { ov.deny.splice(i, 1); return `✅ ${numberOf(j)} autorise a nouveau`; } ov.deny.push(j); return `⛔ ${numberOf(j)} bloque`; });
      db.perms.save(); return c.reply(frame('DENY', [`${c.prefix}${cmd.name}`, ...out]));
    }
  },
  {
    name: 'perms', access: 'owner', desc: 'Affiche les permissions personnalisees', async run(c) {
      const lines = Object.entries(db.perms.data.commands).map(([k, v]) => `🔐 ${k} : ${v.level || 'defaut'}${v.disabled ? ' ⛔off' : ''}${v.allow?.length ? ` +${v.allow.length}ok` : ''}${v.deny?.length ? ` -${v.deny.length}ban` : ''}`);
      const feats = Object.entries(db.perms.data.features).filter(([, v]) => v === false).map(([k]) => `⛔ categorie ${k}`);
      return c.reply(frame('PERMISSIONS', [...lines, ...feats, !lines.length && !feats.length ? 'Aucune personnalisation.' : null]));
    }
  },
  {
    name: 'enable', access: 'owner', desc: 'Active une commande ou une categorie', usage: '.enable <cmd|categorie>', async run(c) { return toggle(c, true); }
  },
  {
    name: 'disable', access: 'owner', desc: 'Desactive une commande ou une categorie', usage: '.disable <cmd|categorie>', async run(c) { return toggle(c, false); }
  },
  {
    name: 'stats', access: 'owner', desc: 'Statistiques du bot', async run(c) {
      const top = Object.entries(db.stats.data.commands).sort((a, b) => b[1] - a[1]).slice(0, 8).map(([k, v], i) => `${i + 1}. ${k} — ${v}`);
      return c.reply(frame('STATS', [`✉️ Messages traites : ${db.stats.data.messages}`, `👥 Utilisateurs : ${Object.keys(db.users.data.list).length}`, `📦 Commandes chargees : ${commands.length}`, `📊 Depuis : ${fmtDate(db.stats.data.startedAt)}`, '', '🏆 Top commandes', ...(top.length ? top : ['(aucune)'])]));
    }
  },
  {
    name: 'errors', aliases: ['logs'], access: 'owner', desc: 'Dernieres erreurs', usage: '.errors [clear]', async run(c) {
      if (c.args[0] === 'clear') { db.errors.data.list = []; db.errors.save(); return c.reply('🧹 Journal d\'erreurs vide.'); }
      const l = db.errors.data.list.slice(0, 6);
      return c.reply(frame(`ERRORS (${db.errors.data.list.length})`, l.length ? l.flatMap((e) => [`🕒 ${fmtDate(e.t)} • ${e.scope}`, `   ${e.msg.slice(0, 160)}`]) : ['✅ Aucune erreur enregistree.']));
    }
  },
  {
    name: 'settings', aliases: ['set'], access: 'owner', desc: 'Voir / modifier les parametres', usage: '.settings [cle valeur]', async run(c) {
      if (!c.args.length) return c.reply(frame('SETTINGS', flat(S()).filter(([k]) => !k.startsWith('nyx.')).map(([k, v]) => `▫️ ${k} = ${JSON.stringify(v)}`), `.settings <cle> <valeur>`));
      const key = c.args[0]; const raw = c.args.slice(1).join(' ');
      const def = getPath(defaultSettings, key);
      if (def === undefined || typeof def === 'object') return c.reply('❌ Cle inconnue. Tapez .settings pour la liste.');
      let val = raw;
      if (typeof def === 'boolean') { if (!/^(on|off|true|false|1|0)$/i.test(raw)) return c.reply('❌ Valeur attendue : on/off.'); val = /^(on|true|1)$/i.test(raw); }
      if (typeof def === 'number') { val = Number(raw); if (!Number.isFinite(val)) return c.reply('❌ Nombre attendu.'); const r = RANGES[key]; if (r && (val < r[0] || val > r[1])) return c.reply(`❌ Valeur hors limites (${r[0]} - ${r[1]}).`); }
      if (key === 'mode' && !['public', 'private'].includes(raw)) return c.reply('❌ public ou private.');
      if (typeof def === 'string' && !raw) return c.reply('❌ Valeur vide.');
      setPath(S(), key, val); db.settings.save(); return c.reply(`✅ ${key} = ${JSON.stringify(val)}`);
    }
  },
  {
    name: 'setprefix', access: 'owner', desc: 'Change le prefixe', usage: '.setprefix <symbole>', async run(c) {
      const p = c.args[0]; if (!p || p.length > 3 || /\s|\w/.test(p)) return c.reply('❌ Prefixe invalide (1 a 3 symboles, sans lettre ni chiffre). Ex : . ! #');
      S().prefix = p; db.settings.save(); return c.reply(`✅ Nouveau prefixe : ${p}`);
    }
  },
  {
    name: 'users', aliases: ['userlist'], access: 'owner', desc: 'Utilisateurs enregistres', usage: '.users [dm]', async run(c) {
      let l = Object.entries(db.users.data.list); if (c.args[0] === 'dm') l = l.filter(([, u]) => u.dm);
      const top = l.sort((a, b) => (b[1].last || 0) - (a[1].last || 0)).slice(0, 20).map(([j, u]) => `👤 ${u.name || '-'} • +${numberOf(j)} • ${u.count} msg${u.dm ? ' • DM' : ''}`);
      return c.reply(frame(`USERS (${l.length})`, top.length ? top : ['Aucun utilisateur.']));
    }
  }
];

function toggle(c, on) {
  const key = c.args[0]?.toLowerCase(); if (!key) return c.reply(`Usage : ${c.prefix}${on ? 'enable' : 'disable'} <commande|categorie>`);
  if (CATEGORIES[key]) { if (key === 'owner' || key === 'general') return c.reply('❌ Cette categorie ne peut pas etre desactivee.'); db.perms.data.features[key] = on; db.perms.save(); return c.reply(`✅ Categorie ${key} ${on ? 'activee' : 'desactivee'}.`); }
  const cmd = findCommand(key); if (!cmd) return c.reply('❌ Commande ou categorie inconnue.');
  if (cmd.category === 'owner' && !on) return c.reply('❌ Les commandes owner ne peuvent pas etre desactivees.');
  (db.perms.data.commands[cmd.name] ||= {}).disabled = !on; db.perms.save();
  return c.reply(`✅ ${c.prefix}${cmd.name} ${on ? 'activee' : 'desactivee'}.`);
}
