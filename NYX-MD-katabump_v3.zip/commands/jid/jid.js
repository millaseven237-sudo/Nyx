import { frame } from '../../lib/ui.js';
import { parseJid, checkJid, formatJidCard, JID_TYPES, GROUP_LINK_RE, CHANNEL_LINK_RE, groupInviteUrl, findJidInText, toUserJid, numberOf } from '../../lib/jidManager.js';
import { extractTargets } from '../../handler/jidHandler.js';
import { findChannelRef, metadata } from '../../lib/channelManager.js';
import { getGroupMeta, invalidateMeta } from '../../lib/groupUtils.js';
import { fmtDate } from '../../lib/utils.js';

const chunk = (lines, max = 3200) => { const out = []; let cur = ''; for (const l of lines) { if ((cur + l).length > max) { out.push(cur); cur = ''; } cur += l + '\n'; } if (cur) out.push(cur); return out; };
const inviteInfo = async (sock, code) => sock.groupGetInviteInfo(code);

export default [
  {
    name: 'jid', desc: 'Votre JID, celui du groupe et le type de conversation', async run(c) {
      const q = c.quoted?.sender;
      const lines = ['👤 *Vous*', formatJidCard(c.sender)];
      const extra = c.senderIds.filter((j) => j !== c.sender); if (extra.length) lines.push(`🔁 Autres identifiants : ${extra.join(', ')}`);
      lines.push('', c.isGroup ? '👥 *Groupe*' : '💬 *Conversation*', formatJidCard(c.chat));
      if (q) lines.push('', '↩️ *Message cite (auteur)*', formatJidCard(q));
      return c.reply(frame('JID', lines));
    }
  },
  {
    name: 'getjid', desc: 'JID d\'un utilisateur mentionne / cite / numero', usage: '.getjid @user | (repondre) | numero', async run(c) {
      const t = extractTargets(c.m, c.args);
      const explicit = findJidInText(c.text); if (explicit && !t.includes(explicit)) t.push(explicit);
      if (!t.length) return c.reply('Mentionnez quelqu\'un, repondez a son message ou donnez un numero : .getjid 237xxxxxxxxx');
      return c.reply(frame('GETJID', t.flatMap((j) => [formatJidCard(j), ''])), { mentions: t.filter((j) => /@(s\.whatsapp\.net|lid)$/.test(j)) });
    }
  },
  {
    name: 'groupjid', aliases: ['gjid'], desc: 'JID du groupe (courant ou via lien d\'invitation)', usage: '.groupjid [lien]', async run(c) {
      const code = (c.text.match(GROUP_LINK_RE) || [])[1];
      if (code) { const i = await inviteInfo(c.sock, code); return c.reply(frame('GROUPJID', [`👥 ${i.subject}`, `🔑 ${i.id}`, `👤 Membres : ${i.size ?? i.participants?.length ?? '?'}`])); }
      if (!c.isGroup) return c.reply('Utilisez cette commande dans un groupe ou donnez un lien : .groupjid https://chat.whatsapp.com/xxxx');
      return c.reply(frame('GROUPJID', [`👥 ${c.meta?.subject || ''}`, `🔑 ${c.chat}`]));
    }
  },
  {
    name: 'link', aliases: ['grouplink', 'gclink'], access: 'admin', group: true, botAdmin: true, desc: 'Lien d\'invitation du groupe', async run(c) {
      const code = await c.sock.groupInviteCode(c.chat);
      if (!code) throw new Error('Impossible de recuperer le code d\'invitation.');
      return c.reply(frame('GROUP LINK', [`👥 ${c.meta?.subject}`, `🔗 ${groupInviteUrl(code)}`]));
    }
  },
  {
    name: 'invitelink', aliases: ['ilink'], access: 'admin', group: true, botAdmin: true, desc: 'Recupere ou regenere le lien d\'invitation', usage: '.invitelink [reset]', async run(c) {
      if (c.args[0]?.toLowerCase() === 'reset') {
        const code = await c.sock.groupRevokeInvite(c.chat); invalidateMeta(c.chat);
        return c.reply(frame('INVITE LINK', ['♻️ Ancien lien revoque', `🔗 ${groupInviteUrl(code)}`]));
      }
      const code = await c.sock.groupInviteCode(c.chat);
      return c.reply(frame('INVITE LINK', [`🔗 ${groupInviteUrl(code)}`, `ℹ️ ${c.prefix}invitelink reset pour en generer un nouveau`]));
    }
  },
  {
    name: 'jidinfo', desc: 'Informations disponibles sur un JID', usage: '.jidinfo <jid|@user|lien>', async run(c) {
      const gl = (c.text.match(GROUP_LINK_RE) || [])[1];
      const lines = [];
      if (gl) {
        const i = await inviteInfo(c.sock, gl);
        lines.push(formatJidCard(i.id), `📛 Nom : ${i.subject}`, `👤 Membres : ${i.size ?? '?'}`, `📅 Creation : ${i.creation ? fmtDate(i.creation * 1000) : '-'}`, `📝 ${(i.desc || '-').slice(0, 300)}`);
        return c.reply(frame('JIDINFO', lines));
      }
      const chRef = findChannelRef({ ...c.m, message: c.m.message }, c.args);
      let jid = findJidInText(c.text) || extractTargets(c.m, c.args)[0] || (chRef?.jid) || (c.isGroup && !c.text ? c.chat : c.sender);
      if (chRef?.invite) { const m = await metadata(c.sock, chRef); jid = m.id; }
      const p = parseJid(jid); lines.push(formatJidCard(jid));
      if (p.type === 'user') {
        try { const r = await c.sock.onWhatsApp(p.user); lines.push(`📲 Sur WhatsApp : ${r?.[0]?.exists ? 'oui' : 'non'}`); } catch {}
        try { const s = (await c.sock.fetchStatus(jid))?.[0]?.status; if (s?.status) lines.push(`💬 A propos : ${s.status}`); } catch { lines.push('💬 A propos : non visible (confidentialite)'); }
        try { const u = await c.sock.profilePictureUrl(jid, 'image'); lines.push(`🖼️ Photo de profil : ${u ? 'visible' : 'aucune'}`); } catch { lines.push('🖼️ Photo de profil : non visible'); }
      } else if (p.type === 'group') {
        try { const m = await getGroupMeta(c.sock, jid); lines.push(`📛 ${m.subject}`, `👤 ${m.participants.length} membres`, `📅 ${m.creation ? fmtDate(m.creation * 1000) : '-'}`); } catch { lines.push('ℹ️ Le bot n\'est pas membre de ce groupe : pas de details (utilisez un lien d\'invitation).'); }
      } else if (p.type === 'newsletter') {
        try { const m = await metadata(c.sock, { jid }); lines.push(`📛 ${m.name}`, `👥 ${m.subscribers} abonnes`, m.link ? `🔗 ${m.link}` : null); } catch (e) { lines.push(`ℹ️ ${e.message}`); }
      } else lines.push('ℹ️ Pas de details supplementaires accessibles pour ce type de JID.');
      return c.reply(frame('JIDINFO', lines));
    }
  },
  {
    name: 'jidcheck', desc: 'Verifie le format et le type d\'un JID', usage: '.jidcheck <jid|numero>', async run(c) {
      let input = c.text.trim(); if (!input) return c.reply('Usage : .jidcheck 2376xxxxxxxx@s.whatsapp.net');
      if (/^\+?\d{6,16}$/.test(input.replace(/[\s-]/g, ''))) input = toUserJid(input);
      const r = checkJid(input); const t = JID_TYPES[r.type];
      const lines = [`${r.ok ? '✅ Format valide' : '❌ Format invalide'}`, `🔑 ${r.raw}`, `${t.emoji} Type : ${t.label}`, r.user ? `🔢 Identifiant : ${r.user}` : null, ...r.problems.map((x) => `⚠️ ${x}`)];
      if (r.ok && r.type === 'user') { try { const e = await c.sock.onWhatsApp(r.user); lines.push(`📲 Compte WhatsApp existant : ${e?.[0]?.exists ? 'oui' : 'non'}`); } catch {} }
      else lines.push('ℹ️ Seul le FORMAT est verifie (l\'existence n\'est testable que pour les numeros).');
      return c.reply(frame('JIDCHECK', lines));
    }
  },
  {
    name: 'jidlist', access: 'admin', group: true, desc: 'JID des membres du groupe', async run(c) {
      const meta = await getGroupMeta(c.sock, c.chat, true);
      const lines = meta.participants.map((p, i) => `${String(i + 1).padStart(3, '0')}. ${p.admin ? '👑' : '▫️'} ${p.id}${p.phoneNumber && p.phoneNumber !== p.id ? ` (${p.phoneNumber})` : ''}${p.lid && p.lid !== p.id ? ` [${p.lid}]` : ''}`);
      const parts = chunk(lines);
      for (let i = 0; i < parts.length; i++) await c.reply(frame(`JIDLIST ${i + 1}/${parts.length} • ${meta.participants.length}`, parts[i].trim().split('\n')));
    }
  },
  {
    name: 'groupinfo', aliases: ['ginfo'], desc: 'Informations detaillees sur le groupe', usage: '.groupinfo [lien]', async run(c) {
      const code = (c.text.match(GROUP_LINK_RE) || [])[1];
      let m; let viaLink = false;
      if (code) { m = await inviteInfo(c.sock, code); viaLink = true; }
      else if (c.isGroup) m = await getGroupMeta(c.sock, c.chat, true);
      else return c.reply('Utilisez la commande dans un groupe ou donnez un lien d\'invitation.');
      const admins = (m.participants || []).filter((p) => p.admin);
      const owner = m.ownerPn || m.owner;
      let link = null; if (!viaLink && c.isBotAdmin) { try { link = groupInviteUrl(await c.sock.groupInviteCode(m.id)); } catch {} }
      return c.reply(frame('GROUP INFO', [`📛 ${m.subject}`, `🔑 ${m.id}`, `👑 Createur : ${owner ? '+' + numberOf(owner) : '-'}`, `📅 Creation : ${m.creation ? fmtDate(m.creation * 1000) : '-'}`, `👥 Membres : ${m.size ?? m.participants?.length ?? '?'}${m.participants?.length ? ` (admins : ${admins.length})` : ''}`, `💬 Messages : ${m.announce ? 'admins seulement' : 'tous'}`, `⚙️ Infos modifiables par : ${m.restrict ? 'admins' : 'tous'}`, `🚪 Approbation d'entree : ${m.joinApprovalMode ? 'oui' : 'non'}`, m.ephemeralDuration ? `⏳ Messages ephemeres : ${m.ephemeralDuration / 3600} h` : null, m.isCommunity ? '🏘️ Communaute' : null, link ? `🔗 ${link}` : null, '', `📝 ${(m.desc || 'Pas de description').slice(0, 500)}`]));
    }
  }
];
