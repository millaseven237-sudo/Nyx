import 'dotenv/config';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/* ╔════════════════════════════════════════════════════════════╗
   ║   🌑 NYX MD — CONFIGURATION (modifiez uniquement ici)       ║
   ╚════════════════════════════════════════════════════════════╝
   Remplissez les valeurs entre guillemets, enregistrez, puis redemarrez.
   (Un fichier .env reste possible : s'il definit une variable, il est prioritaire.) */
const USER_CONFIG = {
  // 👑 Votre numero WhatsApp (proprietaire), format international SANS "+" ni espaces. Ex : '237690000000'
  OWNER_NUMBER: '237600000000',

  // 🤖 Numero du bot a lier par Pairing Code. Laissez vide si c'est le meme que OWNER_NUMBER.
  PAIRING_NUMBER: '',

  BOT_NAME: 'NYX MD',
  PREFIX: '.',                 // symbole des commandes
  MODE: 'public',              // 'public' (tout le monde) ou 'private' (owners seulement)
  TZ: 'Africa/Douala',         // fuseau horaire

  // 🔗 Liens affiches par .repo et .support (facultatif)
  REPO_URL: '',
  SUPPORT_LINK: '',

  // 📢 Votre chaine WhatsApp (facultatif)
  // CHANNEL_JID : de la forme '120363xxxxxxxxxxxx@newsletter'. Pour l'obtenir : envoyez au bot  .channeljid <lien de votre chaine>
  // Effets : le menu s'affiche "transfere depuis votre chaine", .channelpost et .bcchannel la visent par defaut.
  CHANNEL_JID: '',
  CHANNEL_NAME: 'NYX MD',
  CHANNEL_LINK: '',            // ex : 'https://whatsapp.com/channel/xxxxxxxx'

  // 👥 Votre groupe officiel / support (facultatif)
  // GROUP_JID : '1203630xxxxxxxxx@g.us'  (obtenez-le avec .groupjid <lien du groupe>)
  GROUP_JID: '',
  GROUP_NAME: 'NYX MD Support',
  GROUP_LINK: '',              // ex : 'https://chat.whatsapp.com/xxxxxxxxxxxxxxxxxxxxxx'

  // 🔘 Carte cliquable sous les reponses du bot (renvoie vers CHANNEL_LINK, sinon GROUP_LINK). 'on' ou 'off'
  LINK_CARD: 'on',

  // 🔑 Cles API (facultatives — ne partagez jamais ce fichier si vous les remplissez)
  GEMINI_API_KEY: '',          // .caption, .transcribe, IA/vision de .nyx
  GEMINI_MODEL: 'gemini-flash-latest',
  REMOVEBG_API_KEY: '',        // .removebg
  TENOR_API_KEY: ''            // .emojimix
};
/* ───────────────────────── fin de la zone a modifier ───────────────────────── */

const val = (k) => (process.env[k] !== undefined && process.env[k] !== '' ? process.env[k] : USER_CONFIG[k]) ?? '';
const num = (v) => String(v || '').replace(/\D/g, '');

export const config = {
  root: __dirname,
  botName: val('BOT_NAME') || 'NYX MD',
  prefix: val('PREFIX') || '.',
  mode: String(val('MODE')).toLowerCase() === 'private' ? 'private' : 'public',
  ownerNumber: num(val('OWNER_NUMBER')),
  pairingNumber: num(val('PAIRING_NUMBER')) || num(val('OWNER_NUMBER')),
  repoUrl: val('REPO_URL'),
  supportLink: val('SUPPORT_LINK'),
  tz: val('TZ') || 'UTC',
  channelJid: /^\d{10,}@newsletter$/.test(String(val('CHANNEL_JID')).trim()) ? String(val('CHANNEL_JID')).trim() : '',
  channelName: val('CHANNEL_NAME') || 'NYX MD',
  channelLink: val('CHANNEL_LINK'),
  groupJid: /^[\d-]{10,}@g\.us$/.test(String(val('GROUP_JID')).trim()) ? String(val('GROUP_JID')).trim() : '',
  groupName: val('GROUP_NAME') || 'NYX MD Support',
  groupLink: val('GROUP_LINK'),
  linkCard: String(val('LINK_CARD')).toLowerCase() !== 'off',
  gemini: { key: val('GEMINI_API_KEY'), model: val('GEMINI_MODEL') || 'gemini-flash-latest' },
  removebgKey: val('REMOVEBG_API_KEY'),
  tenorKey: val('TENOR_API_KEY'),
  paths: {
    session: path.join(__dirname, 'session'),
    database: path.join(__dirname, 'database'),
    stickers: path.join(__dirname, 'database', 'stickers'),
    media: path.join(__dirname, 'media'),
    statusMedia: path.join(__dirname, 'media', 'status'),
    saved: path.join(__dirname, 'media', 'saved'),
    temp: path.join(__dirname, 'temp'),
    menuImage: path.join(__dirname, 'media', 'menu.png')
  }
};
