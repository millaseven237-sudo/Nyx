// Verifie que tous les modules et commandes se chargent sans erreur : npm run check
import { loadCommands, commands, loadErrors } from '../handler/commandHandler.js';
await loadCommands();
const dup = new Map(); for (const c of commands) dup.set(c.name, (dup.get(c.name) || 0) + 1);
const dups = [...dup].filter(([, n]) => n > 1);
console.log(`${commands.length} commandes OK`, loadErrors.length ? `\nErreurs :\n${loadErrors.join('\n')}` : '', dups.length ? `\nDoublons : ${dups.map(([k]) => k).join(', ')}` : '');
process.exit(loadErrors.length || dups.length ? 1 : 0);
