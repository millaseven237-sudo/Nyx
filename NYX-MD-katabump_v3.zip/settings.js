// Parametres par defaut (modifiables a chaud par l'owner via .settings, stockes dans database/settings.json)
export const defaultSettings = {
  mode: 'public',
  prefix: '.',
  autoReadStatus: false,
  maxMediaMB: 40,            // taille maximale d'un media traite
  maxVideoSeconds: 20,       // duree max pour sticker anime / conversions
  stickerPackLimit: 60,      // limite absolue par pack
  stickerAuthor: 'NYX MD',
  stickerPackName: 'NYX STICKER LAB',
  commandCooldownMs: 1500,
  broadcast: {
    minDelayMs: 4000,        // delai minimal entre deux envois
    jitterMs: 2500,          // delai aleatoire ajoute
    maxRecipientsPerJob: 300,
    dailyCap: 1000,
    repeatWindowMs: 60 * 60 * 1000, // un meme contenu ne peut etre rediffuse avant ce delai
    pauseEveryN: 25,         // pause longue tous les N envois
    pauseMs: 30000
  },
  antispam: { maxMessages: 7, perSeconds: 8 },
  nyx: {
    enabled: true,
    mode: 'auto',            // auto | discret | manual
    persona: 'dark',         // dark | sweet | sarcastic | mystic
    cooldownSec: 20,
    triggers: ['nyx'],
    ai: false                // utilise Gemini si cle presente
  }
};
